/*
 * This reference code is an implementation of
 * a simple Maximum Power Point Tracker using
 * the bq25895 charger driven by the MSP430FR4133.
 *
 * This is only one way of applying a MPPT algorithm
 * using the bq25895. There are other means of MPPT.
 * Users may modify this code to meet their design
 * criteria.
 */

#include <msp430.h> 
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include "I2C_comms.h"
#include "delay_timer.h"
#include "stdbool.h"


#define ENABLE          true
#define DISABLE         false

#define VOC_LOW         65
#define VOC_HIGH        95
#define VBUS_MIN        0X0D
#define SAMPLE_TIME     20

#define ADDRESS         0X6A
#define HIZ_REGISTER    0X00
#define EN_HIZ          0X80

#define IINDPM_REGISTER 0X00
#define IINLIM          0X3F
#define IINDPM_OFFSET   0.100
#define IINDPM_SIZE     0.050

#define ICHG_REGISTER   0X04
#define ICHG            0X7F
#define ICHG_OFFSET     0.000
#define ICHG_SIZE       0.064

#define ADC_REGISTER    0X02
#define CONV_START      0X80
#define CONV_RATE       0X40

#define WDT_REGISTER    0X07
#define WATCHDOG        0X30

#define STAT_REGISTER   0X0B
#define PG_STAT         0X04

#define VINDPM_REGISTER 0X0D
#define FORCE_VINDPM    0X80
#define VINDPM          0X7F

#define VBAT_REGISTER   0x0E
#define BATV            0X7F

#define VSYS_REGISTER   0X0F
#define SYSV            0X7F

#define VBUS_REGISTER   0X11
#define VBUSV           0X7F
#define VBUSV_OFFSET    0X1A

#define ICHGR_REGISTER  0X12
#define ICHGR           0X7F


/*****************************************************************/
/************* Reads back the charger register "reg" *************/
/*****************************************************************/
uint16_t read_Register(unsigned char reg) {
	I2C_write(&reg, 1); //Send register to charger

	unsigned char buffer[1] = { 0x00 };

	I2C_read(buffer, 1); //Read register byte
	return (uint16_t) buffer[0];
}

/*****************************************************************/
/*****8******* Writes to the charger register "reg" *****8********/
/*****************************************************************/
void write_Register(unsigned char reg, unsigned char data) {
    unsigned char buffer[2] = { reg, data };
    I2C_write(buffer, 2);
}

/*****************************************************************/
/************* Disables the charger's watchdog timer *************/
/*****************************************************************/
void disable_CHG_WDT() {
    unsigned char reg = read_Register( WDT_REGISTER );
    write_Register( WDT_REGISTER, (reg & ~(WATCHDOG)) );

}

/*****************************************************************/
/************ Sets the charger's input current limit *************/
/*****************************************************************/
void set_IINDPM(float IINDPM_setting){
    unsigned char reg = read_Register( IINDPM_REGISTER );
    reg &= ~(IINLIM);
    unsigned char iindpm = (char)((int)((IINDPM_setting - IINDPM_OFFSET)/IINDPM_SIZE));
    iindpm |= reg;
    write_Register( IINDPM_REGISTER, iindpm );

}

/*****************************************************************/
/*********** Sets the charger's charging current limit ***********/
/*****************************************************************/
void set_ICHG(float ICHG_setting){
    unsigned char reg = read_Register( ICHG_REGISTER );
    reg &= ~(ICHG);
    unsigned char ichg = (char)((int)( ( ICHG_setting - ICHG_OFFSET ) / ICHG_SIZE ) );
    ichg |= reg;
    write_Register( ICHG_REGISTER, ichg );

}

/*****************************************************************/
/************* Starts the charger's ADC conversion. **************/
/*************** Defaults to burst mode operation. ***************/
/*****************************************************************/
void startADC() {
    unsigned char reg = read_Register( ADC_REGISTER );
    reg |= CONV_START;
    write_Register( ADC_REGISTER, reg );

}

/*****************************************************************/
/*****8**** Returns state of the input source capability *********/
/*****************************************************************/
_Bool get_PGSTAT(){
    unsigned char reg = read_Register( STAT_REGISTER );
    reg &= PG_STAT;

    return reg;
}

/*****************************************************************/
/************ Enables/disables the charger's HIZ Mode ************/
/*****************************************************************/
void set_HIZ(_Bool setting){
    unsigned char reg = read_Register( HIZ_REGISTER );

    if (setting == ENABLE){
        reg |= EN_HIZ;
        write_Register( HIZ_REGISTER, reg );

    }

    else {
        reg &= ~(EN_HIZ);
        write_Register( HIZ_REGISTER, reg );

    }
}

/*****************************************************************/
/**** Returns the charger's ADC reading of the input voltage  ****/
/*****************************************************************/
unsigned char get_VBUS(){
    int i;
    unsigned char reg;
    for (i=0; i<3; i++){
        startADC();

    }
    delay(1);
    reg = read_Register( VBUS_REGISTER );


    unsigned char vbus = (reg & VBUSV);

    return vbus;

}

/*****************************************************************/
/**** Sets the operating voltage through the charger's VINDPM ****/
/*****************************************************************/
void set_VINDPM(char VINDPM_setting){
    unsigned char vindpm = VINDPM_setting;
    vindpm |= FORCE_VINDPM;
    write_Register( VINDPM_REGISTER, vindpm );

}

/*****************************************************************/
/*** Returns the charger's ADC reading of the charging current  **/
/*****************************************************************/
unsigned char get_ICHGR(){
    int i;
    unsigned char reg;
    for (i=0; i<3; i++){
        startADC();
    }
    delay(1);
    reg = read_Register( ICHGR_REGISTER );


    unsigned char ichg = reg;

    return ichg;

}

/*****************************************************************/
/******* Configures the MSP430FR4133's ports/pins for I2C ********/
/*****************************************************************/
void init_ports() {
    PM5CTL0 &= ~(LOCKLPM5);
    P5DIR &= ~(0X0C);
	P5SEL0 |= 0X0C;             // Assign I2C pins to USCI_B0
	LCDPCTL2 &= ~(0X0C);

}

/******************************************************************************************************/
/******************************************* Begin main code ******************************************/
/******************************************************************************************************/
int main(void) {
	WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer

	init_ports();				//Initialize ports on MSP430
	setHostMasterTX(ADDRESS);	//Set charger I2C address


/******************************************************************************************************/
/*************************************** Initialization Routine ***************************************/
/******************************************************************************************************/
	disable_CHG_WDT();			//Disable charger watchdog timer
	set_IINDPM(3.000);          //Set the IINDPM setting to maximum
	set_ICHG(5.056);            //Set the ICHG setting to maximum


    while (1){
        while (get_PGSTAT()){


/******************************************************************************************************/
/*************************************** Preconditioning Routine **************************************/
/******************************************************************************************************/
            set_HIZ(ENABLE);
            unsigned char voc = get_VBUS();         //Reads and stores the ADC measurement of open circuit voltage
            set_HIZ(DISABLE);

            unsigned char voc_low = VOC_LOW*voc/100 - (100-VOC_LOW)*VBUSV_OFFSET/100;   //Sets lower VINDPM limit

            if (voc_low < 0X0D)                     //Clamps lower bound to 3.9V charger setting
                    voc_low = 0X0D;

            unsigned char voc_high = VOC_HIGH*voc/100 - (100-VOC_HIGH)*VBUSV_OFFSET/100; //Sets upper VINDPM limit
            unsigned char ichg_max = 0X0;
            unsigned char vindpm_max = 0X0;

            unsigned char i=0;
            int count=0;


/******************************************************************************************************/
/****************************************** Tracking Routine ******************************************/
/******************************************************************************************************/
            for (i=voc_low ; i<voc_high ; i+=0X01){ //Tracks from the lower to the upper VINDPM limits
                set_VINDPM(i);

                unsigned char ichgr = get_ICHGR();  //Reads and stores the ADC charging current measurement

                if (ichgr > ichg_max){              //Condition to record the current VINDPM @ the max ICHG
                    count = 0;
                    ichg_max = ichgr;
                    vindpm_max = i;

                }

                else if (ichgr == ichg_max){        //Condition to account for the same ICHG ADC readings
                    if (i > vindpm_max){
                        vindpm_max = i;
                        count++;

                    }
                }

                else {
                    //i = voc_high;                 //Optional Tracking Time Optimizer. Uncomment to set

                }
            }

            vindpm_max -= (count/2)*0X01;           //Calculates midpoint. Can be changed different P-V curves
            set_VINDPM( vindpm_max );               //Sets VINDPM operating point to the MPP voltage found

            delay(SAMPLE_TIME);                     //Sets the hold time before the next MPP calculation

        }
    }
}
