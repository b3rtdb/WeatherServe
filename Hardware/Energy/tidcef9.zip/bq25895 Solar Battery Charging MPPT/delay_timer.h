/*
 * delay_timer.h
 *
 *  Created on: Jul 27, 2016
 *      Author: a0224989
 */

#ifndef DELAY_TIMER_H_
#define DELAY_TIMER_H_

/*****************************************************************/
/************ Delay Function set to 1/8th of a second ************/
/*****************************************************************/
void delay(unsigned int delay){
	  TA0CCR0 = 32767;
	  TA0CTL = TASSEL_1 + MC_2 + TACLR;
	  int i;
	  for( i = 0; i < delay; ++i) {
	    TA0R = 0;
	    TA0CCTL0 = CCIE;
	    while(TA0R < 4096);
	  }
	  TA0CTL = 0;
	  TA0CCTL0 = 0;

}



#endif /* DELAY_TIMER_H_ */
