/*
 * I2C_comms.h
 *
 *  Created on: Jun 24, 2016
 *      Author: a0224989
 */

#ifndef I2C_COMMS_H_
#define I2C_COMMS_H_

/**
 * Initialize the USCI module on the MSP430 for I2C operation.
 */
void setHostMasterTX(char slaveAddress) {
    PM5CTL0 &= ~LOCKLPM5;

    // Configure USCI_B0 for I2C mode
    UCB0CTLW0 |= UCSWRST;                   // Software reset enabled
    UCB0CTLW0 |= UCMODE_3 + UCMST + UCSYNC; // I2C mode, Master mode, sync
    UCB0CTLW1 |= UCASTP_2;                  // Automatic stop generated
                                            // after UCB0TBCNT is reached
    UCB0BRW = 0x0002;                       // baudrate = SMCLK / 8
    UCB0TBCNT = 0x0004;                     // number of bytes to be received
    UCB0I2CSA = slaveAddress;                     // Slave address
    UCB0CTL1 &= ~UCSWRST;
}

/**
 * Sending an array of bytes to the device.
 */
void I2C_write(unsigned char *TX_buffer, int writeLength) {
	int i = 0;
	/* Clear USCI_B0 TX interrupt flag */
 	UCB0IFG &= ~UCTXIFG0;

	// Set UCB0 as I2C's TX mode, and send a START condition
	// This will also send out the slave address
	UCB0CTL1 |= UCTR + UCTXSTT;

	//Send the number of "writeLength" bytes out
	for (i = 0; i < writeLength; i++) {

		/* Wait for TX buffer to empty */
		while (!(UCB0IFG & UCTXIFG0))
			;
		/* Send pointer byte */
		UCB0TXBUF = *TX_buffer++;

	}

	/* Wait for TX buffer to empty */
	while (!(UCB0IFG & UCTXIFG0))
		;

	/* Generate Stop condition */
	UCB0CTL1 |= UCTXSTP;
	/* Wait for Stop to finish */
	while (UCB0CTL1 & UCTXSTP)
		;

}

/**
 * Read a fixed amount of bytes from the device and store them in an array.
 */
void I2C_read(unsigned char *RX_buffer, int readLength) {

	int i = 0;

	/* Clear USCI_B0 TX interrupt flag */
	UCB0IFG &= ~UCRXIFG0;

	/* Set UCB0 as I2C Reciever mode */
	UCB0CTL1 &= ~UCTR;

	/* Generate Start condition Read mode
	 * This sends out the slave address and continues to read
	 * until you issue a STOP
	 */
	UCB0CTL1 |= UCTXSTT;

	if (readLength == 1) {
		while (UCB0CTL1 & UCTXSTT)
			; // Has Start condition been sent?
		UCB0CTL1 |= UCTXSTP; // Send I2C stop condition immediately, since we only need to send 1 byte
		/* Wait for Stop to finish */
		while (UCB0CTL1 & UCTXSTP)
			;
		*RX_buffer = UCB0RXBUF;
	}

	if (readLength > 1) {
		for (i = 0; i < (readLength - 1); i++) {
			/* Wait for RX buffer to fill */
			while (!(UCB0IFG & UCRXIFG0))
				;
			/* Read from I2C RX register */
			*RX_buffer++ = UCB0RXBUF;
		}

		/* Generate Stop condition */
		UCB0CTL1 |= UCTXSTP;
		/* Wait for Stop to finish */
		while (UCB0CTL1 & UCTXSTP)
			;
		*RX_buffer = UCB0RXBUF;    //save the last byte
	}
}



#endif /* I2C_COMMS_H_ */
