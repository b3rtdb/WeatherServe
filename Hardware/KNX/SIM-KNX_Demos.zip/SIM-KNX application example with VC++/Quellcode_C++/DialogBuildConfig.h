//------------------------------------------------------------------
// $Workfile: DialogBuildConfig.h $   
// $Archive: /SIMEIB_demo/DialogBuildConfig.h $     

// $Author: Thiere_m $         
// 
// Copyright Tapko Technologies GmbH
// 
// $Date: 27.06.06 15:29 $
// $Revision: 1 $         
//------------------------------------------------------------------
#if !defined(AFX_DIALOGBUILDCONFIG_H__D68A9287_0106_4C2C_98FA_A0CB3F23283F__INCLUDED_)
#define AFX_DIALOGBUILDCONFIG_H__D68A9287_0106_4C2C_98FA_A0CB3F23283F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogBuildConfig.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CDialogBuildConfig 

class CDialogBuildConfig : public CDialog
{
// Konstruktion
public:
	CDialogBuildConfig(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(CDialogBuildConfig)
	enum { IDD = IDD_BUILD_CONFIG };
	CButton	m_bOk;
	CButton	m_cRcvValueControl;
	CComboBox	m_coDPT;
	CButton	m_cSendChangeControl;
	CButton	m_cSendRisingControl;
	CStatic	m_sObjectType;
	CEdit	m_eObjectType;
	int		m_rbSendRcvTimer;
	int		m_rbSeconds;
	int		m_coFlagsPrio;
	CString	m_eResult;
	int		m_eObjectNo;
	int		m_eObjectTypeValue;
	int		m_eRepTime;
	BOOL	m_cSendRising;
	BOOL	m_cSendChange;
	BOOL	m_cRcvChange;
	BOOL	m_cSendRcv;
	BOOL	m_cRcvOnRcv;
	BOOL	m_cRcvValue;
	BOOL	m_cRcvTimeout;
	int		m_rbRcvGlobal;
	int		m_coFlagsCommDir;
	//}}AFX_DATA
  
  CString m_bOkText;
// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CDialogBuildConfig)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CDialogBuildConfig)
	virtual BOOL OnInitDialog();
	afx_msg void CreateResult();
	afx_msg void OnSelchangeCodpt();
	afx_msg void OnIndicationType();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_DIALOGBUILDCONFIG_H__D68A9287_0106_4C2C_98FA_A0CB3F23283F__INCLUDED_
