//------------------------------------------------------------------
// $Workfile: SIMEIB_demo.cpp $   
// $Archive: /SIMEIB_demo/SIMEIB_demo.cpp $     

// $Author: Thiere_m $         
// 
// Copyright Tapko Technologies GmbH
// 
// $Date: 27.06.06 15:29 $
// $Revision: 1 $         
//------------------------------------------------------------------
// SIMKNX_demo.cpp : Definiert den Einsprungpunkt f�r die Konsolenanwendung.
//

#include "stdafx.h"
#include "SIMKNX_demo.h"
#include "comport.h"
#include "dialogappl.h"
#include "DIalogBuildConfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Das einzige Anwendungsobjekt

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;
	// MFC initialisieren, Ausgabe und Fehlermeldung bei Fehlern
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
    if ((argc>1) && strcmp(argv[1],"/ConfigManager") == 0)
    { // start only the Configurationmanger-Dialog
      CDialogBuildConfig dlg;
      dlg.DoModal();
    }
    else
    { // start the Communictaion-Dialog
		  CString strApp;
	  	strApp.LoadString(IDS_APPLICATION);
  		cout << (const TCHAR*)strApp << endl;
      CDialogAppl dlg;
      dlg.DoModal();
    }
	}

	return nRetCode;
}


