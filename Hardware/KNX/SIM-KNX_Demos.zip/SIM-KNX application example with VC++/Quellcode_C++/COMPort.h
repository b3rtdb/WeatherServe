//------------------------------------------------------------------
// $Workfile: COMPort.h $   
// $Archive: /SIMEIB_demo/COMPort.h $     

// $Author: Thiere_m $         
// 
// Copyright Tapko Technologies GmbH
// 
// $Date: 27.06.06 15:29 $
// $Revision: 1 $         
//------------------------------------------------------------------
// ComPort.h: Schnittstelle f�r die Klasse CComPort.
//

#if !defined(toosten_COMPORT_H)
#define toosten_COMPORT_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>

class CCOMPort  
{
public:
	CCOMPort();										
	~CCOMPort();									
	bool Close();
	bool IsOpen();									
	int Receive(void *buffer, int MAXBYTES);		
	bool Send(CString &buffer);	
	bool Send(const char *buffer);	
	bool Init(CString port, COMMTIMEOUTS *comtiming=0, int Baud =9600, int Size =8, int Parity =0, int stopbit=0); 
private:
	HANDLE m_hPort;
};

#endif // !defined(toosten_COMPORT_H)

