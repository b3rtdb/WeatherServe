//------------------------------------------------------------------
// $Workfile: COMPort.cpp $   
// $Archive: /SIMEIB_demo/COMPort.cpp $     

// $Author: Thiere_m $         
// 
// Copyright Tapko Technologies GmbH
// 
// $Date: 27.06.06 15:29 $
// $Revision: 1 $         
//------------------------------------------------------------------
// ComPort.cpp: Implementierung der Klasse CComPort.
//

#include "stdafx.h"
#include "ComPort.h"
#include <stdio.h>
#include <iostream.h>
#include <string.h>


//////////////////////////////////////////////////////////////////////
// Constructor / Destructor
//////////////////////////////////////////////////////////////////////
CCOMPort::CCOMPort()
{
	this->m_hPort= INVALID_HANDLE_VALUE;						
}

CCOMPort::~CCOMPort()
{
	this->Close();							
}

//------------------------------------------------------------------
// Init
// Open a COM-Port and set the parameter
// inputs: port:      name of the Serial Interface (e.g. "COM1")
//         iBaud:     baudrate (default=9600)
//         iSize:     Number of Databits (default=8)
//         iParity    selected parity (default=0)
//         stopbit    Number of stopbits (default=0)
//         *comtiming pointer to struct with timings 
//                    will be ignored, if it is set to zero (default=0) 
//------------------------------------------------------------------
bool CCOMPort::Init(CString port, COMMTIMEOUTS *comtiming, int iBaud, int iSize, int iParity, int stopbit)
{
        // try to open the COM-Port
	  m_hPort = CreateFile(	port, 
		GENERIC_READ | GENERIC_WRITE, 
		0, 
		NULL, 
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL, 
		NULL);

	if(this->IsOpen())					    //Check if COM-Port could be opened
	{
		if (comtiming!=0)
      SetCommTimeouts(this->m_hPort, comtiming);

		DCB dcb;							        // Set the Interface-Parameter
		GetCommState(this->m_hPort, &dcb);
		dcb.BaudRate= iBaud;
		dcb.ByteSize= iSize;
		dcb.DCBlength= 28;
		dcb.EofChar= 0;
		dcb.ErrorChar= 0;
		dcb.fRtsControl= RTS_CONTROL_HANDSHAKE;
		dcb.Parity= iParity;
		dcb.StopBits= stopbit;
		dcb.fInX=0;
		dcb.fOutX=0;
		dcb.fAbortOnError= false;
		SetCommState(this->m_hPort, &dcb);
		return true;
	}

	return false;
}

//------------------------------------------------------------------
// Send
//  Sends datas to the COM-Port 
// inputs: buffer:      pointer to the datas 
//------------------------------------------------------------------
bool CCOMPort::Send(CString &buffer)
{
  return Send((const char*) buffer);
}

bool CCOMPort::Send(const char *buffer)
{
	DWORD written= 0;						

	if(IsOpen())
	{										
		WriteFile(this->m_hPort, buffer, strlen(buffer), &written, NULL);
  	if(strlen(buffer) == written)						
      return true;
	}
	return false;
}

//------------------------------------------------------------------
// Receive
// Get the datas to the COM-Port 
// inputs:    len:    maximum length of the buffer
//            buffer  pointer, where the rcvd datas could be written
// return     length of the received string
//------------------------------------------------------------------
int CCOMPort::Receive(void *buffer, int len)
{
	DWORD receive=0;
	if(this->IsOpen() && len >0)
  	ReadFile(m_hPort, buffer, len, &receive, NULL);

  return receive;
}


//------------------------------------------------------------------
// IsOpen
// Check if the COM-Port is opened
// return:      true, if the port is opened
//------------------------------------------------------------------
bool CCOMPort::IsOpen()
{
	if(m_hPort != INVALID_HANDLE_VALUE)
		return true;
	return false;
}

//------------------------------------------------------------------
// Close
// Disconnect the COM-Port
// return:      true, if the port is closed
//------------------------------------------------------------------
bool CCOMPort::Close()
{
	if(this->IsOpen())
	{
		CloseHandle(this->m_hPort);
		this->m_hPort= INVALID_HANDLE_VALUE;	
		return true;
	}
	return false;
}


