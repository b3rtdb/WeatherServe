//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SIMKNX_demo.rc
//
#define IDS_HELLO                       1
#define IDS_APPLICATION                 1
#define IDR_MENU                        102
#define IDD_BUILD_CONFIG                103
#define IDD_APPLIKATION_DEMO            106
#define IDI_TAPKO                       108
#define IDR_MAINFRAME                   108
#define IDC_SET_CONFIGURATION           1003
#define IDC_SLIDER1_0_100               1004
#define IDC_SET_CONFIGURATION2          1005
#define IDC_OBJ0_ON_OFF                 1006
#define IDC_SET_RESET                   1007
#define IDC_SLIDER_4_100                1010
#define IDC_SLIDER4_0_100               1010
#define IDC_OBJ3_ON_OFF                 1011
#define IDC_OBJ3_TIMEOUT                1012
#define IDC_OBJ2_TEMP                   1013
#define IDC_OBJ5_TEMP                   1014
#define IDC_SPIN_TEMP                   1015
#define IDC_OBJ_TEMP_SEND               1016
#define IDC_OBJ3_CYCLE                  1017
#define IDC_CCOMPORT                    1018
#define IDC_BOPENCOMPORT                1019
#define IDC_EOBJECT                     1020
#define IDC_BSEND                       1020
#define IDC_OBJ0_CYCLE2                 1021
#define IDC_OBJ0_CYCLE                  1021
#define IDC_EEISTYPE                    1022
#define IDC_BCLOSECOMPORT               1022
#define IDC_EOBJECTTYPE                 1022
#define IDC_EREPTIME                    1023
#define IDC_CSENDRCV                    1024
#define IDC_CSENDCHANGE                 1025
#define IDC_CSENDRISING                 1026
#define IDC_ERESULT                     1032
#define IDC_RADIO1                      1033
#define IDC_RADIO2                      1034
#define IDC_RADIO3                      1035
#define IDC_RADIO4                      1036
#define IDC_CRCVONRCV                   1039
#define IDC_CRCVCHANGED                 1040
#define IDC_CRCVTIMEOUT                 1041
#define IDC_COPRIO                      1045
#define IDC_COFLAGCOMMDIR               1046
#define IDC_CODPT                       1050
#define IDC_SEISTYPE                    1051
#define IDC_SOBJECTTYPE                 1051
#define IDC_COECHO                      1052
#define IDC_SINDICATION                 1053
#define IDC_RADIO5                      1054
#define IDC_SSTATUS                     1054
#define IDC_RADIO6                      1055
#define IDC_CRCVVALUE                   1056
#define IDM_Exit                        40001
#define IDS_EMPTY                       40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1055
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
