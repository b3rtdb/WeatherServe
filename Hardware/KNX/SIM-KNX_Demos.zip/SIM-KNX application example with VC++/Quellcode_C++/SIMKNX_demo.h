//------------------------------------------------------------------
// $Workfile: SIMEIB_demo.h $   
// $Archive: /SIMEIB_demo/SIMEIB_demo.h $     

// $Author: Thiere_m $         
// 
// Copyright Tapko Technologies GmbH
// 
// $Date: 27.06.06 15:29 $
// $Revision: 1 $         
//------------------------------------------------------------------

#if !defined(AFX_SIMKNX_DEMO_H__998B1841_AE05_466F_BB83_586EAE0652F4__INCLUDED_)
#define AFX_SIMKNX_DEMO_H__998B1841_AE05_466F_BB83_586EAE0652F4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_SIMKNX_DEMO_H__998B1841_AE05_466F_BB83_586EAE0652F4__INCLUDED_)
