//------------------------------------------------------------------
// $Workfile: DialogAppl.h $   
// $Archive: /SIMEIB_demo/DialogAppl.h $     

// $Author: Thiere_m $         
// 
// Copyright Tapko Technologies GmbH
// 
// $Date: 17.07.06 17:13 $
// $Revision: 4 $         
//------------------------------------------------------------------
#if !defined(AFX_DIALOGAPPL_H__C43F3312_6153_4690_8E26_D4DAA6F41C93__INCLUDED_)
#define AFX_DIALOGAPPL_H__C43F3312_6153_4690_8E26_D4DAA6F41C93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogAppl.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CDialogAppl 

class CDialogAppl : public CDialog
{
// Konstruktion
public:
	CDialogAppl(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(CDialogAppl)
	enum { IDD = IDD_APPLIKATION_DEMO };
	CButton	m_bOpenCom;
	CButton	m_bCloseCom;
	CStatic	m_sIndicationControl;
	CComboBox	m_cbComPort;
	int		m_slider1_0to100;
	int		m_slider4_0to100;
	BOOL	m_obj0OnOff;
	BOOL	m_obj3OnOff;
	int		m_coEcho;
	float	m_obj2Temp;
	float	m_obj5Temp;
	BOOL	m_obj0Cycle;
	BOOL	m_obj3Cycle;
	BOOL	m_obj3Timeout;
	CString	m_sIndication;
	//}}AFX_DATA
  void EvaluateRxString(void* rxString);
  void SimKNX_Send(CString &buffer);
  bool CheckReceive(void *rcvdLine);

  bool m_waitForAnswer;
  CString m_rxBuffer;

// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CDialogAppl)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

  CCOMPort m_comPort;

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CDialogAppl)
	virtual BOOL OnInitDialog();
	afx_msg void OnObjOnOff();
	afx_msg void OnSetConfiguration();
	afx_msg void OnSetfocusCcomport();
	afx_msg void OnBopenComPort();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSetConfigurationManager();
	afx_msg void OnSetReset();
	afx_msg void OnBsend();
	afx_msg void OnBclosecomport();
	afx_msg void OnPaint();
	//}}AFX_MSG
  void OnReleasedCaptureSlider0100(NMHDR* pNMHDR, LRESULT* pResult);
  void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_DIALOGAPPL_H__C43F3312_6153_4690_8E26_D4DAA6F41C93__INCLUDED_
