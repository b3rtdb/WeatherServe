//------------------------------------------------------------------
// $Workfile: DialogBuildConfig.cpp $   
// $Archive: /SIMEIB_demo/DialogBuildConfig.cpp $     

// $Author: Thiere_m $         
// 
// Copyright Tapko Technologies GmbH
// 
// $Date: 27.06.06 15:29 $
// $Revision: 1 $         
//------------------------------------------------------------------
// DialogBuildConfig.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "SIMKNX_demo.h"
#include "DialogBuildConfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CDialogBuildConfig 
enum EPriority
{
  prio_system = 0x00,
  prio_alarm = 0x02,
  prio_high = 0x01,
  prio_low = 0x03
};

#define CO_commEnable          0x04
#define CO_readEnable          0x08
#define CO_writeEnable         0x10
#define CO_memType             0x20
#define CO_transmitEnable      0x40
#define CO_readResponseEnable  0x80

#define CO_T       (CO_commEnable | CO_transmitEnable)
#define CO_RT      (CO_commEnable | CO_transmitEnable | CO_readEnable)
#define CO_W       (CO_commEnable | CO_writeEnable)
#define CO_WU      (CO_commEnable | CO_writeEnable | CO_readResponseEnable)
#define CO_RWU     (CO_commEnable | CO_writeEnable | CO_readEnable | CO_readResponseEnable)
#define CO_R       (CO_commEnable | CO_readEnable)


#define DPT1        1
#define NO_DPT      0
const enum EPriority c_priorityValues[]={prio_low,prio_high,prio_alarm,prio_system};
const unsigned char c_ramFlags[]=                 // has to be in trhe same order like at Combobox for selection
                                  {CO_T,          // Send
                                   CO_RT,         // Send / Readenable
                                   CO_W,          // Receive
                                   CO_WU,         // Receive / ReadUpdate
                                   CO_T | CO_RWU, // Enable all
                                   0};            // Disable Object

typedef struct 
{
  char      dptString[30];
  unsigned char dptValue;
  char      dptDescription[40];
} SDptForDropdown;

const SDptForDropdown c_dropdownlist[] = {{"No DPT selectetd" , NO_DPT,  "ObjectType"},   
                                          {"DPT1"             , DPT1,    "Boolean"},
                                          {"DPT2"             , 2,       "1-Bit Controlled"},
                                          {"DPT3"             , 3,       "3-Bit Controlled"},
                                          {"DPT4"             , 4,       "Character Set"},
                                          {"DPT5 0..255"      , 201,     "8-Bit Unsigned Value"},
                                          {"DPT5 0..100%"     , 5,       "8-Bit Unsigned Value, 0..100%%"},
                                          {"DPT5 0..360�"     , 200,     "8-Bit Unsigned Value, 0..360�"},
                                          {"DPT6"             , 6,       "8-Bit Signed Value"},
                                          {"DPT7"             , 7,       "2-Octet Unsigned Value"},
                                          {"DPT8"             , 8,       "2-Octet Signed Value"},
                                          {"DPT9"             , 9,       "2-Octet Float Value"},
                                          {"DPT10"            ,10,       "Time"},
                                          {"DPT11"            ,11,       "Date"},
                                          {"DPT12"            ,12,       "4-Octet Unsigned Value"},
                                          {"DPT13"            ,13,       "4-Octet Signed Value"},
                                          {"DPT14"            ,14,       "4-Octet Float Value"},
                                          {"DPT15"            ,15,       "Access"},
                                          {"DPT16"            ,16,       "String"},
                                          {"DPT17"            ,17,       "Scene"},
                                          {"DPT18"            ,18,       "Scene Control"},
                                          {"DPT19"            ,19,       "DateTime"},
                                          {"DPT20"            ,20,       ""},
                                          {"DPT21"            ,21,       "general status"},
                                          {"DPT22"            ,22,       "16-Bit Set"},
                                          {"DPT23"            ,23,       ""},
                                          {""                 , 0,       "" } };   // must be last entry




CDialogBuildConfig::CDialogBuildConfig(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogBuildConfig::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogBuildConfig)
	m_rbSendRcvTimer = 0;
	m_rbSeconds = 0;
	m_coFlagsPrio = 0;
	m_eResult = _T("");
	m_eObjectNo = 0;
	m_eObjectTypeValue = 0;
	m_eRepTime = 0;
	m_cSendRising = FALSE;
	m_cSendChange = FALSE;
	m_cRcvChange = FALSE;
	m_cSendRcv = FALSE;
	m_cRcvOnRcv = FALSE;
	m_cRcvValue = FALSE;
	m_cRcvTimeout = FALSE;
	m_rbRcvGlobal = 0;
	m_coFlagsCommDir = 0;
	//}}AFX_DATA_INIT
  
}


void CDialogBuildConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogBuildConfig)
	DDX_Control(pDX, IDOK, m_bOk);
	DDX_Control(pDX, IDC_CRCVVALUE, m_cRcvValueControl);
	DDX_Control(pDX, IDC_CODPT, m_coDPT);
	DDX_Control(pDX, IDC_CSENDCHANGE, m_cSendChangeControl);
	DDX_Control(pDX, IDC_CSENDRISING, m_cSendRisingControl);
	DDX_Control(pDX, IDC_SOBJECTTYPE, m_sObjectType);
	DDX_Control(pDX, IDC_EOBJECTTYPE, m_eObjectType);
	DDX_Radio(pDX, IDC_RADIO3, m_rbSendRcvTimer);
	DDX_Radio(pDX, IDC_RADIO1, m_rbSeconds);
	DDX_CBIndex(pDX, IDC_COPRIO, m_coFlagsPrio);
	DDX_Text(pDX, IDC_ERESULT, m_eResult);
	DDX_Text(pDX, IDC_EOBJECT, m_eObjectNo);
	DDV_MinMaxInt(pDX, m_eObjectNo, 0, 255);
	DDX_Text(pDX, IDC_EOBJECTTYPE, m_eObjectTypeValue);
	DDV_MinMaxInt(pDX, m_eObjectTypeValue, 0, 14);
	DDX_Text(pDX, IDC_EREPTIME, m_eRepTime);
	DDV_MinMaxInt(pDX, m_eRepTime, 0, 255);
	DDX_Check(pDX, IDC_CSENDRISING, m_cSendRising);
	DDX_Check(pDX, IDC_CSENDCHANGE, m_cSendChange);
	DDX_Check(pDX, IDC_CRCVCHANGED, m_cRcvChange);
	DDX_Check(pDX, IDC_CSENDRCV, m_cSendRcv);
	DDX_Check(pDX, IDC_CRCVONRCV, m_cRcvOnRcv);
	DDX_Check(pDX, IDC_CRCVVALUE, m_cRcvValue);
	DDX_Check(pDX, IDC_CRCVTIMEOUT, m_cRcvTimeout);
	DDX_Radio(pDX, IDC_RADIO5, m_rbRcvGlobal);
	DDX_CBIndex(pDX, IDC_COFLAGCOMMDIR, m_coFlagsCommDir);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogBuildConfig, CDialog)
	//{{AFX_MSG_MAP(CDialogBuildConfig)
	ON_EN_CHANGE(IDC_EOBJECT, CreateResult)
	ON_CBN_SELCHANGE(IDC_CODPT, OnSelchangeCodpt)
	ON_BN_CLICKED(IDC_RADIO5, OnIndicationType)
	ON_EN_CHANGE(IDC_EOBJECTTYPE, CreateResult)
	ON_EN_CHANGE(IDC_EREPTIME, CreateResult)
	ON_BN_CLICKED(IDC_RADIO1, CreateResult)
	ON_BN_CLICKED(IDC_RADIO3, CreateResult)
	ON_BN_CLICKED(IDC_RADIO2, CreateResult)
	ON_BN_CLICKED(IDC_RADIO4, CreateResult)
	ON_BN_CLICKED(IDC_CSENDRCV, CreateResult)
	ON_BN_CLICKED(IDC_CSENDCHANGE, CreateResult)
	ON_BN_CLICKED(IDC_CSENDRISING, CreateResult)
	ON_BN_CLICKED(IDC_CRCVVALUE, CreateResult)
	ON_BN_CLICKED(IDC_CRCVONRCV, CreateResult)
	ON_BN_CLICKED(IDC_CRCVCHANGED, CreateResult)
	ON_BN_CLICKED(IDC_CRCVTIMEOUT, CreateResult)
	ON_BN_CLICKED(IDC_RADIO6, OnIndicationType)
	ON_CBN_SELCHANGE(IDC_COPRIO, CreateResult)
	ON_CBN_SELCHANGE(IDC_COFLAGCOMMDIR, CreateResult)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CDialogBuildConfig 

//------------------------------------------------------------------
// CreateResult
//  is calld on every change 
//  Creates the Configuration-string
//------------------------------------------------------------------
void CDialogBuildConfig::CreateResult(void)
{
  unsigned sendConfig;
  unsigned rcvConfig;
  unsigned flags;

  UpdateData(TRUE);
  
  // create the value for the Send-Configuration
  sendConfig = m_cSendRcv            |        // BIT0:  send on receive
               m_cSendChange << 1    |        // BIT1:  send on change   or send on falling edge for DPT1
               m_cSendRising << 2    |        // BIT2:  send on falling edge
               m_rbSendRcvTimer << 6 |        // BIT6:  selection of the timer usage
               m_rbSeconds << 7;              // BIT7:  selection of the time base

  // create the value for the Receive-Configuration
  rcvConfig  = m_cRcvOnRcv  << 11  |          // BIT11: indication on rcv
               m_cRcvChange << 12  |          // BIT12: indication on changed
               m_cRcvTimeout << 15 |          // BIT15: indication on timeout
               m_cRcvValue << 1    |          // BIT1:  format of the single-indication
               m_rbRcvGlobal;                 // BIT0:  single/global Indication

  // create the value for the configuration-flags
  flags = c_priorityValues[m_coFlagsPrio] | c_ramFlags[m_coFlagsCommDir];
          ;

  sprintf(m_eResult.GetBuffer(50),"ocs (%d) $%02X $%02X $%02X $%04X $%04X %d"
                                        ,m_eObjectNo                                    // Object-Number
                                        ,c_dropdownlist[m_coDPT.GetCurSel()].dptValue   // DataPointType
                                        ,m_eObjectTypeValue                             // Objecttype
                                        ,flags                                          // configuration-flags
                                        ,sendConfig                                     // send-Configuration
                                        ,rcvConfig                                      // receive-Configuration
                                        ,m_eRepTime                                     // repetition-Time
                                        );
  UpdateData(FALSE);
}


//------------------------------------------------------------------
// OnInitDialog
// set the default configuration for the dialog
//------------------------------------------------------------------
BOOL CDialogBuildConfig::OnInitDialog() 
{
	unsigned index=0;
  CDialog::OnInitDialog();
  
  // Fill the ComboBox with the DPT-Values
  while (0 != memcmp(c_dropdownlist[index].dptString,"",strlen(c_dropdownlist[index].dptString)))
  {
    m_coDPT.AddString(c_dropdownlist[index].dptString);
    index++;
  }
  // Set the text for the Submit-Button, if requested
  if (m_bOkText!="")                  
    m_bOk.SetWindowText(m_bOkText);


  m_coDPT.SetCurSel(0);
  OnSelchangeCodpt();
  OnIndicationType();
  CreateResult();     
  
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}


//------------------------------------------------------------------
// OnSelchangeCodpt
// Handles the diffent views on DPT-changes
//------------------------------------------------------------------
void CDialogBuildConfig::OnSelchangeCodpt() 
{
  UpdateData(TRUE);

  // Enable/Disable the editfield for the Objecttype
  m_eObjectType.ShowWindow(c_dropdownlist[m_coDPT.GetCurSel()].dptValue == NO_DPT);

  // set the descriptionstring for the selected DPT
  CString helpString;
  helpString.Format(c_dropdownlist[m_coDPT.GetCurSel()].dptDescription);
  m_sObjectType.SetWindowText(helpString);

  // set the descriptionstring for the selected DPT
  m_cSendChangeControl.SetWindowText("Send on Change");
  
  // Set Objecttype to 0, if any DPT is selected 
  //    is not really necessary, because it will be handled from SIM-KNX
  if (c_dropdownlist[m_coDPT.GetCurSel()].dptValue != NO_DPT)
    m_eObjectTypeValue = 0;        
                                    
  
  // Handle differnt views for DPT1
  m_cSendRisingControl.ShowWindow(c_dropdownlist[m_coDPT.GetCurSel()].dptValue == DPT1);
  if (c_dropdownlist[m_coDPT.GetCurSel()].dptValue == DPT1)
    m_cSendChangeControl.SetWindowText("Send on Falling Edge");
  else
    m_cSendRising=0;

  UpdateData(FALSE);
  CreateResult();
}


//------------------------------------------------------------------
// OnIndicationType
// Handles the diffent views for the indication-types
//------------------------------------------------------------------
void CDialogBuildConfig::OnIndicationType() 
{
  UpdateData(TRUE);
  // disable Response-Value, if global indication is used  
	m_cRcvValueControl.ShowWindow(m_rbRcvGlobal==0);      
  if (m_rbRcvGlobal!=0)
    m_cRcvValue = 0;
  UpdateData(FALSE);
  CreateResult();
}

