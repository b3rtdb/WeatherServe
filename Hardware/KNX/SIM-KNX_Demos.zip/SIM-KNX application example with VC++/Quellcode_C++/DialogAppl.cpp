//------------------------------------------------------------------
// $Workfile: DialogAppl.cpp $   
// $Archive: /SIMEIB_demo/DialogAppl.cpp $     

// $Author: Thiere_m $         
// 
// Copyright Tapko Technologies GmbH
// 
// $Date: 17.07.06 17:13 $
// $Revision: 7 $         
//------------------------------------------------------------------
// DialogAppl.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "SIMKNX_demo.h"
#include "comport.h"
#include "DialogAppl.h"
#include "DialogBuildConfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define TIMER_RX            1
#define TIMER_CLEAR_TEXT    2
#define FlashWriteTimeout() Sleep(250)
/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CDialogAppl 


CDialogAppl::CDialogAppl(CWnd* pParent /*=NULL*/)
	: CDialog(CDialogAppl::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogAppl)
	m_slider1_0to100 = 0;
	m_slider4_0to100 = 0;
	m_obj0OnOff = FALSE;
	m_obj3OnOff = FALSE;
	m_coEcho = 0;
	m_obj2Temp = 0.0f;
	m_obj5Temp = 0.0f;
	m_obj0Cycle = TRUE;
	m_obj3Cycle = TRUE;
	m_obj3Timeout = FALSE;
	m_sIndication = _T("");
	//}}AFX_DATA_INIT
  m_waitForAnswer = FALSE;

}


void CDialogAppl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogAppl)
	DDX_Control(pDX, IDC_BOPENCOMPORT, m_bOpenCom);
	DDX_Control(pDX, IDC_BCLOSECOMPORT, m_bCloseCom);
	DDX_Control(pDX, IDC_SINDICATION, m_sIndicationControl);
	DDX_Control(pDX, IDC_CCOMPORT, m_cbComPort);
	DDX_Slider(pDX, IDC_SLIDER1_0_100, m_slider1_0to100);
	DDX_Slider(pDX, IDC_SLIDER4_0_100, m_slider4_0to100);
	DDX_Check(pDX, IDC_OBJ0_ON_OFF, m_obj0OnOff);
	DDX_Check(pDX, IDC_OBJ3_ON_OFF, m_obj3OnOff);
	DDX_CBIndex(pDX, IDC_COECHO, m_coEcho);
	DDX_Text(pDX, IDC_OBJ2_TEMP, m_obj2Temp);
	DDV_MinMaxFloat(pDX, m_obj2Temp, -671088, 670760);
	DDX_Text(pDX, IDC_OBJ5_TEMP, m_obj5Temp);
	DDV_MinMaxFloat(pDX, m_obj5Temp, -671088, 670760);
	DDX_Check(pDX, IDC_OBJ0_CYCLE, m_obj0Cycle);
	DDX_Check(pDX, IDC_OBJ3_CYCLE, m_obj3Cycle);
	DDX_Check(pDX, IDC_OBJ3_TIMEOUT, m_obj3Timeout);
	DDX_Text(pDX, IDC_SINDICATION, m_sIndication);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogAppl, CDialog)
	//{{AFX_MSG_MAP(CDialogAppl)
	ON_BN_CLICKED(IDC_OBJ0_ON_OFF, OnObjOnOff)
	ON_BN_CLICKED(IDC_SET_CONFIGURATION, OnSetConfiguration)
	ON_CBN_SETFOCUS(IDC_CCOMPORT, OnSetfocusCcomport)
	ON_BN_CLICKED(IDC_BOPENCOMPORT, OnBopenComPort)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_SET_CONFIGURATION2, OnSetConfigurationManager)
	ON_BN_CLICKED(IDC_SET_RESET, OnSetReset)
	ON_BN_CLICKED(IDC_BSEND, OnBsend)
	ON_BN_CLICKED(IDC_BCLOSECOMPORT, OnBclosecomport)
	ON_WM_CREATE()
  ON_WM_HSCROLL()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()




/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CDialogAppl 

BOOL CDialogAppl::OnInitDialog() 
{
  CDialog::OnInitDialog();

  this->m_rxBuffer.Empty();
  OnSetfocusCcomport();

  HICON hIcon = (HICON)::LoadImage(AfxGetResourceHandle(), 
     MAKEINTRESOURCE(IDR_MAINFRAME), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
  SetIcon(hIcon,true);	

  return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//------------------------------------------------------------------
// OnObjOnOff
// Send the value, which is set from the user for Object0 (On/off)
//------------------------------------------------------------------
void CDialogAppl::OnObjOnOff() 
{
	CString simKNXCmd = "ovs(0) ";

  UpdateData(TRUE);
  if (m_obj0OnOff)
    simKNXCmd += "1";
  else
    simKNXCmd += "0";
  SimKNX_Send(simKNXCmd);	
}


//------------------------------------------------------------------
// OnHScroll
// Help-Function to handle the slider, also if it is changed with the keyboard
//------------------------------------------------------------------
void CDialogAppl::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
  LRESULT pResult;
  if(pScrollBar == GetDlgItem(IDC_SLIDER1_0_100))
  {
    switch (nSBCode)
    {
      case 8:
      OnReleasedCaptureSlider0100(NULL,&pResult);
    }      
  }
} 

//------------------------------------------------------------------
// OnReleasedCaptureSlider0100
// Send the value, which is set from the user for Object1 (0..100%)
//------------------------------------------------------------------
void CDialogAppl::OnReleasedCaptureSlider0100(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CString simKNXCmd;

  UpdateData(TRUE);
  simKNXCmd.Format("ovs(1) %d", m_slider1_0to100);
  
  SimKNX_Send(simKNXCmd);
	*pResult = 0;
}

//------------------------------------------------------------------
// OnObjOnOff
// Send the value, which is set from the user for Object2 (Temperature)
//------------------------------------------------------------------
void CDialogAppl::OnBsend() 
{
  UpdateData(TRUE);
  CString simKNXCmd;
  simKNXCmd.Format("ovs (2) %0.2f", m_obj2Temp);
  SimKNX_Send(simKNXCmd);
}

//------------------------------------------------------------------
// OnSetConfiguration
// Sends the default-configuration for this demo
//------------------------------------------------------------------
void CDialogAppl::OnSetConfiguration() 
{
  CString simKNXCmd;
  unsigned char cycleTimer;

  UpdateData(TRUE);

  // Write Echo-Syntax
  simKNXCmd.Format("ids (5 52) %d", m_coEcho);
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout(); 

  // Initialization of object 0 as 1 bit object (sending) (on/off)
  cycleTimer = 0;
  if (m_obj0Cycle)
    cycleTimer = 10;
  simKNXCmd.Format("ocs(0) 1 0 $4f $0001 $0000 %d", cycleTimer);
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout();

  simKNXCmd = "ogs(0) 1/1/100";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout(); 
  

  // Initialization of object 1 as 8 bit object (sending) (0-100%)
  simKNXCmd = "ocs(1) 5 0 $4f $0002 $0000 0";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout(); 

  simKNXCmd = "ogs(1) 1/1/101";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout();

  // Initialization of object 2 as 2 byte floating object (sending) (Temperature)
  simKNXCmd = "ocs(2) 9 0 $4f $0001 $0000 0";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout();

  simKNXCmd = "ogs(2) 1/1/102";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout();

  // Initialization of object 3 as 1 bit object (receiving) (on/off)
  cycleTimer = 0;
  if (m_obj0Cycle)
    cycleTimer = 10;
  simKNXCmd.Format("ocs(3) 1 0 $97 $0040 $8802 %d", cycleTimer);
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout();

  simKNXCmd = "ogs(3) 1/1/103";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout(); 
  

  // Initialization of object 4 as 8 bit object (receiving) (0-100%)
  simKNXCmd = "ocs(4) 5 0 $97 $0000 $1002 0";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout(); 

  simKNXCmd = "ogs(4) 1/1/104";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout();

  // Initialization of object 5 as 2 byte floating object (receiving) (Temperature)
  simKNXCmd = "ocs(5) 9 0 $97 $0000 $0802 0";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout();

  simKNXCmd = "ogs(5) 1/1/105";
  SimKNX_Send(simKNXCmd);
  FlashWriteTimeout();
}

//------------------------------------------------------------------
// OnSetfocusCcomport
// searches for free COM-Ports
//------------------------------------------------------------------
void CDialogAppl::OnSetfocusCcomport() 
{
	unsigned index;
  CString helpString;
  CCOMPort helpPort;

  if (m_comPort.IsOpen())
    return;

  m_cbComPort.ResetContent();         // clear the Combo-Box
  for (index=1;index<20; index++)
  {
    helpString.Format("COM%d",index);
    if (helpPort.Init(helpString))    // Check if the COM-Port could be 0pened
    {
      helpPort.Close();               // Close COM-Port
      m_cbComPort.AddString(helpString);
    }
  }
  m_cbComPort.SetCurSel(0);           // select first entry
}


//------------------------------------------------------------------
// OnBopenComPort
// open the selected COM-Port
//------------------------------------------------------------------
void CDialogAppl::OnBopenComPort() 
{

  if (m_cbComPort.GetCurSel()==-1)
    puts("Select a COM-PORT!");
  else
  {
    // Close an alredy opened Port
    m_comPort.Close();

    COMMTIMEOUTS comtiming;
    CString simKNXCmd;
    CString comPort;
    // set special timeouts
    comtiming.ReadIntervalTimeout=MAXDWORD;
    comtiming.ReadTotalTimeoutConstant=0;
    comtiming.ReadTotalTimeoutMultiplier=0;
    comtiming.WriteTotalTimeoutConstant=0;
    comtiming.WriteTotalTimeoutMultiplier=1000; // max 1 secs to write data, if anythig in the application goes wrong

    m_cbComPort.GetWindowText(comPort);
    if (m_comPort.Init(comPort,&comtiming))   // open the port
    {
      puts("Connection succesful");
      simKNXCmd.Format("");           // send \r for synchronisation
      SimKNX_Send(simKNXCmd);
    }
    else
      puts("Connection failed");

  }
  SetTimer(TIMER_RX, 100, 0);         // Start timer for rcv-checks
  OnPaint();
}


//------------------------------------------------------------------
// EvaluateRxString
// Analyse the received string
//------------------------------------------------------------------
void CDialogAppl::EvaluateRxString(void* rxString)
{
  unsigned data[3];
  float dataf;
  if (!m_waitForAnswer)
  {
    UpdateData(TRUE);

    if (sscanf((const char *)rxString,"gui $%d", data)!=0)
    {                           // command "gui" was received
      if ((data[0] & 0x01) != 0)
        m_sIndication = _T("Reset of the device");

      UpdateData(FALSE);
      SetTimer(TIMER_CLEAR_TEXT, 2000, 0);
      
      // handle other global indications
      // !!! todo !!! 
    }
    else if (sscanf((const char *)rxString,"oui $%x $%x %f", &data[0],&data[1],&dataf)!=0) 
    {                           // command "oui" was received
      m_sIndication.Format("Update of Object %d", data[0]);
      switch (data[0])    // check object-Number
      {
        case 3:          
           m_obj3OnOff= (dataf!=0);
           m_obj3Timeout = (data[1] & 0x80) != 0;
          break;
        case 4:
           m_slider4_0to100= dataf;
          break;
        case 5:
          m_obj5Temp= dataf;
          break;
        default:
          ;
      }
      UpdateData(FALSE);
      SetTimer(TIMER_CLEAR_TEXT, 2000, 0);      // set timer to clear the text
    }
  }
  else
  {
    //  handle responses (e.g. reponse on ovg(0))
    // !!! todo !!! 
  }
  
}

//------------------------------------------------------------------
// OnTimer
// Handle the timer-events
//------------------------------------------------------------------
void CDialogAppl::OnTimer(UINT nIDEvent) 
{
  CString rcvdLine;
  
  switch (nIDEvent)
  {
  case TIMER_RX:          // check the COM-Port for received datas
    if (CheckReceive(rcvdLine.GetBuffer(90)))
    {
      rcvdLine.ReleaseBuffer();
      EvaluateRxString(rcvdLine.GetBuffer(90));
      rcvdLine.ReleaseBuffer();
    }
  	SetTimer(TIMER_RX, 100, 0);
    break;

  case TIMER_CLEAR_TEXT:  // clear the indication-message
      m_sIndicationControl.SetWindowText("");
    break;
  }

	CDialog::OnTimer(nIDEvent);
}



//------------------------------------------------------------------
// OnSetConfigurationManager
// Calls the Dialog with the Configuration-Manager and sends the string
//------------------------------------------------------------------
void CDialogAppl::OnSetConfigurationManager() 
{
  CDialogBuildConfig dlg;
  dlg.m_bOkText="Send";
  if (dlg.DoModal() == IDOK)
    SimKNX_Send(dlg.m_eResult);
}

//------------------------------------------------------------------
// OnSetReset
// send the command to reset the SIM-KNX to manufacturer State
//------------------------------------------------------------------
void CDialogAppl::OnSetReset() 
{
  CString simKNXCmd;
  simKNXCmd.Format("gci");
  SimKNX_Send(simKNXCmd);
}



//------------------------------------------------------------------
// OnBclosecomport
// Close the COM-Port
//------------------------------------------------------------------
void CDialogAppl::OnBclosecomport() 
{
  m_comPort.Close();
  KillTimer(TIMER_RX);
  puts("Connection Closed");
  OnPaint();
}


//------------------------------------------------------------------
// SimKNX_Send
//  Sends datas to the COM-Port and write the written datas
//  to the Console
// inputs: buffer:      pointer to the datas 
//------------------------------------------------------------------
void CDialogAppl::SimKNX_Send(CString &buffer)
{
  OnTimer(TIMER_RX);      // Check for Received-Lines
  if (m_comPort.Send(buffer))
  {
    putchar('>');
    putchar('>');
    putchar(' ');
    puts(buffer);
    m_comPort.Send("\r");
  }
  else
  {
    puts("COM-PORT is closed!");
  }
}


//------------------------------------------------------------------
// CheckReceive
// Get the datas to the COM-Port 
// and writes the rcvd datas to the Console
// inputs:    rcvdLine pointer, where the rcvd datas could be written
// return     true, if a complete line was received
//------------------------------------------------------------------
bool CDialogAppl::CheckReceive(void *rcvdLine)
{
  CString addRx,t;
  unsigned len;
  if ((len=m_comPort.Receive(addRx.GetBuffer(90),89)) != 0)
  {
    addRx.ReleaseBuffer();
    addRx.SetAt(len,0);
    m_rxBuffer.Insert(m_rxBuffer.GetLength(),addRx);
    m_rxBuffer.ReleaseBuffer();
  }

  if ((len = m_rxBuffer.Find("\n\r"))!= -1)   // received-string is finished
  { 
    putchar('<');   // Write to Console
    putchar('<');
    putchar(' ');
    puts(m_rxBuffer.Left(len));
    sprintf((char *)rcvdLine,"%s",m_rxBuffer.Left(len));
    m_rxBuffer.Delete(0,len+2);
    m_rxBuffer.ReleaseBuffer();
    return TRUE;
  }
  return FALSE;
}


void CDialogAppl::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
  m_bCloseCom.ShowWindow(m_comPort.IsOpen());
  m_bOpenCom.ShowWindow(!m_comPort.IsOpen());
  m_cbComPort.EnableWindow(!m_comPort.IsOpen());



	
}
