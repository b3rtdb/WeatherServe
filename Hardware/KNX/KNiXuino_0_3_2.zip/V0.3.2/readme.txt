/******************************************************************************* 
KNiXuino Library Package - Arduino Libraries to connect an KNX Bus System and an
Arduino.

Copyright (C) 2017 knixuino.com
All Info and documentation under http://www.knixuino.com

Version Beta 0.3.2
********************************************************************************


Copy these 3 Directories into your Arduino / Libraries Folder and restart the
Arduino IDE. Older Versions of KNiXuino Library will collide with this version, so you have to delete them (or move outside of the Libraries Dir).

Have Fun !