#include "taskPlanner.h"

taskPlanner::taskPlanner(void (*function)(), unsigned long i)
{
    callbackFunction = function;
    interval = i;
    active = true;
    lastCall = 0;
}

void taskPlanner::doIt()
{
	unsigned long now;
    if (!active) return;
    now = millis();
    if(now - lastCall > interval)
    {
        lastCall = now;
        if (callbackFunction != NULL) callbackFunction();
    }
}