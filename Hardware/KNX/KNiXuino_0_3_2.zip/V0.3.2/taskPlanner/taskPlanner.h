// ************** KNiXuino - KNX Bus and Arduino ****************
//
// taskPlanner is part of the KNiXuino Library. You can use it on its own if you like.
// No dependencies to other parts of the Library
// But include licence and readme of KNixuino Library if distributed !!
//
// for further info check http://www.knixuino.com
// Version info - _readme.txt (in KNiXuino Dir)
// Copyright info - _licence.txt (in KNiXuino Dir)
// Do not remove this headerinfo !!!!


#ifndef taskPlanner_h
#define taskPlanner_h

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

class taskPlanner
{
private:
    bool active;
    unsigned long interval;
    unsigned long lastCall;
    void (*callbackFunction)();

public:
    taskPlanner(void (*function)(), unsigned long i);

    void doIt();
    void setInterval(unsigned long i) { interval = i; }
    
    void setActive(bool a) { active = a; }
    bool getActive() { return active; }
    
    unsigned long elapsed() { return (millis() - lastCall); }
};

#endif 