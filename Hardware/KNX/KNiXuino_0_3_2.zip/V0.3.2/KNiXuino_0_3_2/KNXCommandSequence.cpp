// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!


#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include "KNXCommandSequence.h"
#include "KNXConnection.h" 



KNXCommandSequence:: KNXCommandSequence(uint16_t ga): KNXObject(ga) {
	commandList = NULL;
	startTime = 0;
	}

void KNXCommandSequence::add(KNXObject& obj, uint8_t value, uint16_t delay) {
	KNXCommand *cmd = new KNXCommand(&obj, value, delay);
	addCommand(cmd);	
	}

void KNXCommandSequence::addCommand(KNXCommand* cmd) {
	cmd->next = commandList;
	commandList = cmd;	
	}

// reset setzt alle Kommandos auf undone (für neuen Ablauf)
void KNXCommandSequence::reset() {
	
	KNXCommand *ptr = commandList;
	while(ptr != NULL) {
		ptr->reset();
		ptr = ptr->next;		
	}
}


// CommandoSequenz ausführen
// muss im Loop aufgerufen werden, damit alle Kommandos zur richtigen Zeit abgearbeitet werden.
void KNXCommandSequence::start() {
	reset();
	startTime=millis();
}

void KNXCommandSequence::set(uint8_t value) {
	KNXObject::set(value);
	if(value==1) {
		start();	
	}
	if(value==0) {
		reset();	
		startTime = 0;		
	}
}

void KNXCommandSequence::doIt() {
	if (startTime != 0) { 
	  uint16_t elapsed = (millis()-startTime) / 100; // in 1/10 sek.
	  KNXCommand *ptr = commandList;

	  uint8_t done = 1;
	  while(ptr != NULL) {
		ptr->doIt(elapsed);
		if (!ptr->isDone()) done = 0;	
		ptr = ptr->next;	
	  }
	
	// after all commands are done, switch the whole sequence to off.
	if (done) { off();
		}
	}
}

void KNXCommandSequence::print() {
	KNXObject::print();
	Serial.println("---Befehlliste");
	  KNXCommand *ptr = commandList;

	  while(ptr != NULL) {
		ptr->print();
		ptr = ptr->next;	
	  }


}


// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
	

KNXCommand::KNXCommand(KNXObject* obj, uint8_t val, uint16_t del) : object(obj), value(val), delayT(del) {}

void KNXCommand::reset() { done = false; }

void KNXCommand::doIt(uint16_t act) { 
	if (!done) {
		if (delayT < act) {
			object->set(value);	
			done = true;
			delay(2);
		}
	}	
}

void KNXCommand::print() {
	Serial.print("Value:");	
	Serial.print(value);	
	Serial.print(" --- Delay:");	
	Serial.print(delayT);	
	Serial.print(" ---- done:");	
	Serial.println(done);	
	
}