// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!


#ifndef KNXObject_h
#define KNXObject_h

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

class KNXConnection;


// group address functions. (a group address is strored in one 16 bit variable.)
// conversion between 3-part group address and 16bit value is done with these functions
    inline uint16_t ga (uint8_t first, uint8_t second, uint8_t third) {return (uint16_t)first << 11 | second << 8 | third; }

//    uint8_t getFirst(uint16_t ad);
//    uint8_t getSecond(uint16_t ad);    
//    uint8_t getThird(uint16_t ad);
        

 
class KNXObject
{
	public:

	KNXObject(uint16_t ga, uint8_t s = 0);
	KNXObject(uint16_t ga, uint16_t status, uint8_t s = 0);
	virtual ~KNXObject();

   	uint8_t* data;     

		
	// Group Addresses 
	uint16_t        getGroupAddress()          const { return groupAddress; };
	virtual uint8_t isCheckingStatus()         const { return statusGA!=0;} // returns if the object has any status GA
	uint16_t        getStatusGroupAddress()    const { return statusGA; };
	virtual boolean isListeningTo(uint16_t ga) const;


	// bit methods - for accessing data bits (see below)
	void setStatusBit(boolean value) {if (value) bitSet(flags, 2); else bitClear(flags, 2);}
	uint8_t getStatusBit() const {return bitRead(flags, 2);}

	void setInternalBit(boolean value) {if (value) bitSet(flags, 3); else bitClear(flags, 3);}
	uint8_t getInternalBit() const {return bitRead(flags, 3);}

	void setWebOutBit(boolean value) {if (value) bitSet(flags, 4); else bitClear(flags, 4);}
	uint8_t getWebOutBit() const {return bitRead(flags, 4);}

	void setWebInBit(boolean value) {if (value) bitSet(flags, 5); else bitClear(flags, 5);}
	uint8_t getWebInBit() const {return bitRead(flags, 5);}

	void setReadRqBit(boolean value) {if (value) bitSet(flags, 6); else bitClear(flags, 6);}
	uint8_t getReadRqBit() const {return bitRead(flags, 6);}

	void setWebBits(boolean value) {setWebOutBit(value); setWebInBit(value);}


		virtual void on()     { set((uint8_t)1); }
		virtual void off()    { set((uint8_t)0); }
		virtual void toggle() { set((uint8_t)!get()); }



	// value was received from KNX Bus. -> change value internally, but no writing to KNX
	// char* expects a string as sent from the SIMKNX. Used for Values longer than 1 Byte
    virtual void receivedFromKNX(uint16_t ga, char* value);
    virtual void print();

    // set the value of the object + send to KNX
    virtual void set(uint8_t data);
    //virtual void set(uint8_t* data);
    //virtual void operator ()(uint8_t data) { set(data); } 

	// setLong renamed from set, otherwise casts are necessary when numbers are passed ( obj.set((byte)1); )
    virtual void setLong(const uint8_t[]); 
	virtual void setLong(const uint16_t d);

	virtual uint8_t get() const { return data[0]; };
    virtual uint8_t operator ()() const { return get(); } 

    virtual void readRequest(); // write a read request into the KNX

	// Loop method. Do things here, that have to be done permanently
	virtual void doIt() {} // not used at the moment !




	protected:
		uint16_t flags;          // flags !
		   // bit 1: left blank (used by bit object as data bit)
		   // bit 2: status (Status confirmed)
		   // bit 3: internal (Arduino is the managing Device itself)
		   //        internal = there is no external device. arduino is the device itself. so after
		   //        receiving a new value a status message is sent back if the statusGA is defined
		   // bit 4: Web Out -> Values are sent to the WEB (= can be read in the WebApp)
		   // bit 5: Web In  -> Values may be changed via the web.
		   // bit 6: regularReadRequests  -> actual Value should be read from Bus regulaly

		const uint16_t groupAddress;     // main GA for swicthing ob/off
		const uint16_t statusGA;         // GA for incoming Status Messages (usually resonse from actor)
		const uint8_t  size; 			 // 0 = Bit
										 // 1 = 1 Byte
										 // 2 = 2 Byte .....

		virtual void writeToKNX(uint16_t g = 0);     // write DATA to KNX via SIM-KNX
													 // group can be set to status GA, if 0, normal GA is used

		uint8_t hex2Byte(char*);

};

#endif 