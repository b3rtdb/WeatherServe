// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!



#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
#include "KNXMultiSwitchStatus.h"


extern unsigned long seconds;

KNXMultiSwitchStatusObject::KNXMultiSwitchStatusObject(KNXObject* obj): object(obj) {}

KNXMultiSwitchStatus::KNXMultiSwitchStatus(uint16_t sa): KNXObject(0, sa){
	switchList = NULL;
	setInternalBit(1); // MultiSwitchStatus only makes sense as internal switch !
}

void KNXMultiSwitchStatus::add(KNXObject *obj) {
	KNXMultiSwitchStatusObject* msso = new KNXMultiSwitchStatusObject(obj);
	msso->next = switchList;
	switchList = msso;	
} // end method

void KNXMultiSwitchStatus::add(KNXObject &obj) {
	KNXMultiSwitchStatusObject* msso = new KNXMultiSwitchStatusObject(&obj);
	msso->next = switchList;
	switchList = msso;	
} // end method


// --- checked auf updates und sendet status, falls änderung
void KNXMultiSwitchStatus::doIt() {
	KNXMultiSwitchStatusObject *ptr = switchList;
	uint8_t allOff = 1;
	while(ptr != NULL) {
		if (ptr->object->get()) {
			allOff = 0;	
		}
		ptr = ptr->next;		
	}

	if (allOff == get()) {
		if (allOff) KNXObject::set((uint8_t)0); else KNXObject::set((uint8_t)1); // use on/off of KNXObject, otherwise all swithces are switched to on/off !!
	}
}


void KNXMultiSwitchStatus::print() {
	KNXObject::print();
	Serial.println("-------- single Objects: -------");
	KNXMultiSwitchStatusObject *ptr = switchList;
	while(ptr != NULL) {
		ptr->object->print();
		ptr = ptr->next;		
	}
}


void KNXMultiSwitchStatus::set(uint8_t val) {
	KNXObject::set(val);
	KNXMultiSwitchStatusObject *ptr = switchList;
	while(ptr != NULL) {
		ptr->object->set(val);
		ptr = ptr->next;		
	}
}



