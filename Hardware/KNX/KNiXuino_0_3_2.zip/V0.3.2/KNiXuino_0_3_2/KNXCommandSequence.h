// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!


#ifndef KNXCommandSequence_h
#define KNXCommandSequence_h

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
  
#include "KNXConnection.h" 


//-- Eine CommandSequence erzeut eine Abfolge von KNX Befehlen, die mit bestimmten Delay ausgeführt werden



// -- Command to be used in a Command Sequence
// -- delay in 1/10 of seconds !!!
class KNXCommand {
	public:	
		KNXCommand(KNXObject* obj, uint8_t value, uint16_t delay);
		void doIt(uint16_t delay);
		void reset();
		KNXCommand* next;
		uint8_t isDone() { return done; }
		void print();
	private:
		KNXObject *object;
		uint8_t value; // zu sendender Wert
		uint16_t delayT; //(1/10 seconds)
		uint8_t done;
};



class KNXCommandSequence : public KNXObject{
	public:	
		KNXCommandSequence(uint16_t ga = 0);
		void add(KNXObject& obj, uint8_t value, uint16_t delay);
		void addCommand(KNXCommand*);
		void doIt(); // loopfunktion
		void start(); // startet die kommandosequenz
		void reset(); // setzt die Kommandokette zurück (alle Command auf nicht done)
		void set(uint8_t value); // wert wird geändert -> starten !
		void print();
	private:
		KNXCommand* commandList;
		uint32_t startTime; // millis als das letzte mal gestartet worden ist

};





#endif 