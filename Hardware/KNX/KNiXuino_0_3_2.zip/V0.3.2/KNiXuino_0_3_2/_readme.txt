/******************************************************************************* 
KNiXuino Library Package - Arduino Libraries to connect an KNX Bus System and an
Arduino.

Copyright (C) 2014 knixuino.com
All Info and documentation under http://www.knixuino.com

Version Beta 0.3  


********************************************************************************
Version History:
Beta 0.1 (2014)
  First public release. Use with care ! Not all code is tested !

0.2. (2014)
  Change to transparent mode on SIM-KNX. Complete redesign.

0.2.2 (2016)
  Bugfixes, more example Sketches

0.2.3 
  Bugfix: receivedFromKNX Method was not called for KNXByte Objects

0.3 (early 2017)

  General:
    implemented Tasks and StatusTimer
    removed dependencies to elapsedMillis (elapsedMillis no mor part of the distribution)
    renamed function for GA-conversion to ga (from gaToInt) for clearer definition file

  Changes to Library Structure:
    renamed examples a,b,c,d… for sorting reasons
    changed to one Object Class for all DPTs 
    changed class hierarchy. no abstract connection class and simknx class, just one KNCConnection class
    reading of KNX Serial Stream via SerialEvent1 Function AND interrupt 
              (-> no knx->doIt in loop necessary any more, no timing problems, when you make longer calculations in der Loop etc.)
    cleaned up const methods (methods that can be const should be const now)



  ChangesTo KNXObject and Subclasses
    added ()operator (instead of get method) 
    group address, StatusAdress and size changed to const 
    


  ChangesTo Special Classes
    major changes due to changes in KNXObject and KNXConnection






*********************************************************************************

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
***********************************************************************************/

This Package includes third party software (Arduino Libraries). Please check 
Copyright notices there. 
