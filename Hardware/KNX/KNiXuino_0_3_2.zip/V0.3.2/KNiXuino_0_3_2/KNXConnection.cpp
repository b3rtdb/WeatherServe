// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!


#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include "KNXConnection.h"

extern KNXConnection knx;



void serialEvent1(){
	knx.readSerial();
}


ISR(TIMER4_COMPA_vect)         
{
  knx.readSerial();
}




KNXConnection::KNXConnection() {
	for (int i = 0; i < MaxListeningObjects; i++) {
		listeningObjects[i] = 0;
	}
	restartIterator();
	
	term='\r'; // terminating character of a knx message
	//KNXSerialStream = &Serial1;
	KNXSerialStream.begin(9600);
	clearBuffer(); 
	
  noInterrupts();           
  TCCR4A = 0;
  TCCR4B = 0;
  TCNT4  = 0;

  OCR4A = 400;      // interrupt frequency around 150Hz which is fastre than the serial connection between SIM-KNX and Arduino       
  TCCR4B |= (1 << WGM12);   
  TCCR4B |= (1 << CS12);     
  TIMSK4 |= (1 << OCIE4A);
  interrupts();             

}



void KNXConnection::sendDataToObject(uint16_t ga, char* data) const {
	int i = 0;
	while(listeningObjects[i]) { 
		listeningObjects[i]->receivedFromKNX(ga, data);
		i++;
	}
}

void KNXConnection::doIt() {
	readSerial();
	int i = 0;
	while(listeningObjects[i]) { 
		listeningObjects[i]->doIt();
		i++;
	}
}


void KNXConnection::readRequest(uint16_t ga) const { 
	if (!ga) return;
	KNXSerialStream.print("trs ($");
	KNXSerialStream.print(ga, HEX);
	KNXSerialStream.println(")");

			#if defined(KNXConnectionDebug)
	Serial.print("trs ($");
	Serial.print(ga, HEX);
	Serial.println(")");
			#endif
	}







void KNXConnection::addListeningObject(KNXObject* obj) {
	uint8_t i = 0;
	while(listeningObjects[i] != NULL) { i++; }
	
	if (i >= MaxListeningObjects) {
			#if defined(KNXConnectionDebug)
				KNXConnectionDebug.println("Max. listening Objects reached.");
			#endif
		return;
	}
	listeningObjects[i]=obj;
	listeningObjects[i+1]=NULL;
}



// unused at the moment !
/*
KNXObject* KNXConnection::getObjectFromGA_unused(uint16_t ga) {
	uint8_t i = 0;
	while(listeningObjects[i] != NULL) { 
		if (listeningObjects[i]->getGroupAddress()==ga) return listeningObjects[i];
		i++; 
	}
	return false;
}
*/



//
// Initialize the command buffer being processed to all null characters
//
void KNXConnection::clearBuffer()
{
	for (int i = 0; i < KNXStreamBUFFER; i++) {
		buffer[i]='\0';
	}
	bufPos=0; 
}



// -- Stream auf eingegenagen Daten prüfen --
void KNXConnection::readSerial() 
{   
	//KNXSerialStream.flush();
	while (KNXSerialStream.available() > 0) 
	{
		int i; 
		incomingByte= KNXSerialStream.read();  				
		if (incomingByte==term) {    		
			bufPos=0;       
			#if defined(KNXConnectionDebug)
				KNXConnectionDebug.print("KNX in:");
				KNXConnectionDebug.println(getBuffer());
			#endif
   
			incoming(); 
			clearBuffer(); 
		}
		else    
		{
			if (isprint(incomingByte)) {
				buffer[bufPos++]=incomingByte; 
				buffer[bufPos]='\0';  
				if (bufPos > KNXStreamBUFFER-1) { bufPos=0; }
			}
		}
	}
}


// incoming is called after the Buffer has received a whole line from the SIM-KNX -> parse line and act accordingly
void KNXConnection::incoming() {
	char *tok;
	char *limits=(char*)" <>()$";
		
    tok = strtok_r(getBuffer(), limits, &last);
	
	if (strcmp("tdi", tok)==0 || strcmp("tdc", tok)==0 || strcmp("tei", tok)==0) {
		// tdi (source dest length) data
		// source = physical address of sending device
		// dest = group address
		// length = length in bytes 0 = 1-6 bit 
		// data = data (hex)
		// tdi ($111E $1924 $00) $01
		// tdc is sent as confirmation from the sim-KNX if data is written to KNX Bus via SIM-KNX (normally switched off)
		// tei is the answer of an other KNX device to a read request

		char part[8];
		strcpy (part,"0x");
		strcat(part, strtok_r(NULL, limits, &last));
		int pa = strtol(part, NULL, 16);
		int ga = int(strtol(strtok_r(NULL, limits, &last), NULL, 16));
		int length = int(strtol(strtok_r(NULL, limits, &last), NULL, 16));
		
		sendDataToObject(ga, last);	
	}	
} // end method incoming


void KNXConnection::write(uint16_t ga, uint8_t data, uint8_t bits) {
	if (!ga) return;
	
	KNXSerialStream.print("tds ($");
	KNXSerialStream.print(ga, HEX);
	
	if (bits < 8) KNXSerialStream.print(") ");
	if (bits == 8) KNXSerialStream.print(" $01) ");
	if (bits == 16) KNXSerialStream.print(" $02) ");
	
	KNXSerialStream.println(data);

	#if defined(KNXConnectionDebug)
	KNXConnectionDebug.print("tds ($");
	KNXConnectionDebug.print(ga, HEX);
	
	if (bits < 8) KNXConnectionDebug.print(") ");
	if (bits == 8) KNXConnectionDebug.print(" $01) ");
	if (bits == 16) KNXSerialStream.print(" $02) ");
	
	KNXConnectionDebug.println(data);
			#endif
	
	}


