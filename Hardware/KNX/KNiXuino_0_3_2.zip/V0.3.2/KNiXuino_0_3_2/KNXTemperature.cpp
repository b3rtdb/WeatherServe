
#include "KNXTemperature.h"


// ----------------- KNX Temperature ------------------------------

KNXTemperature::KNXTemperature(uint16_t ga): KNXObject(ga, 0, 2) {}

// convert 2-Byte Data to a float variable according to DPT9 Specification (Temperature)
float KNXTemperature::getFloat() const {
	if (size != 2) return 0.0;
	
	uint16_t dat;
	dat=data[0]<<8 | data[1];

	int32_t val  = dat & 2047;          // binary 0000 0111 1111 1111
	uint8_t bit1 = dat & 32768;         // binary 1000 0000 0000 0000
	uint16_t exp = (dat & 30720) >> 11; // binary 0111 1000 0000 0000

	if (bit1) { 
		val = val | 4294965248;          // hex ff ff f8 00
		val = val * (-1);
	}

	val = val << exp;
	if (bit1) val = val * (-1);

	float flval = val * 0.01;
	return flval;
}

// set data with float value as parameter
void KNXTemperature::setFloat(float fv) {
	uint8_t sign=0;
	uint16_t val = fv*100;
	
	if (val < 0) sign = 1; 
	uint16_t dpt = 0;
	uint8_t  exp = 0;

	if (sign) { 
		dpt= 32768; // binär 1000 0000 0000 0000
		val = val * (-1); 
	}

  	while (val > 2047) // binär 111 1111 1111
  	{
    	val = val >> 1;
    	exp++;
  	}	

	if (sign) { val = val * (-1); }
	
	dpt = dpt | (val & 2047);          // binär 111 1111 1111
	dpt = dpt | ((exp << 11) & 30720); // binär 0111 1000 0000 0000
	dpt = dpt & 65535;                 // binär 1111 1111 1111 1111

	set(dpt);

}





