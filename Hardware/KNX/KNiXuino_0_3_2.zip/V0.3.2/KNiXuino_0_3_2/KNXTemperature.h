// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!

#ifndef KNXLongObject_h
#define KNXLongObject_h
#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif 
#include "KNXConnection.h"
#include "KNXObject.h"


class KNXTemperature:public KNXObject {

	public:
		KNXTemperature(uint16_t ga); 

		float getFloat() const;
		void  setFloat(float fv);

};



#endif 