// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!

#ifndef KNXDate_h
#define KNXDate_h
#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif 
#include "KNXConnection.h"
#include "KNXObject.h"
//#include "TimeLib.h"
#include "../time/TimeLib.h"

class KNXDate:public KNXObject {

	public:
		KNXDate(uint16_t ga); 

		void setD(uint8_t d, uint8_t m, uint8_t y);
		virtual void writeToKNX(uint16_t g = 0);
		virtual void receivedFromKNX(uint16_t ga, char* value);

};



#endif 