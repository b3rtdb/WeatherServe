
#include "KNXDate.h"
//#include "TimeLib.h"

// ----------------- KNX Temperature ------------------------------

KNXDate::KNXDate(uint16_t ga): KNXObject(ga, 0, 3) {}

// convert 2-Byte Data to a float variable according to DPT9 Specification (Temperature)
void KNXDate::setD(uint8_t d, uint8_t m, uint8_t y) {
	setTime(hour(), minute(), second(), (int)d, (int)m, (int)y);
	writeToKNX();
}

void KNXDate::writeToKNX(uint16_t group) {	
	data[0] = (uint8_t)day();
	data[1] = (uint8_t)month();
	data[2] = (uint8_t)year();	

	KNXObject::writeToKNX(group);	
}

void KNXDate::receivedFromKNX(uint16_t ga, char* value) {
	KNXObject::receivedFromKNX(ga, value);
	setTime(hour(), minute(), second(), (int) data[0],(int) data[1],(int)data[2]);
	
}
