// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!

#ifndef KNXTime_h
#define KNXTime_h
#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif 
#include "KNXConnection.h"
#include "KNXObject.h"
//#include <TimeLib.h>
#include "../time/TimeLib.h"


class KNXTime:public KNXObject {

	public:
		KNXTime(uint16_t ga); 

		void setT(uint8_t h, uint8_t min, uint8_t sec);
		virtual void writeToKNX(uint16_t g = 0);
		virtual void receivedFromKNX(uint16_t ga, char* value);

};



#endif 