// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!

#ifndef KNXMultiSwitchStatus_h
#define KNXMultiSwitchStatus_h

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
  
#include "KNXConnection.h"


/*

KNXMultiSwitchStatus beobachtet passiv mehrere Lampen (KNX Objekte)

Es erfolgt eine Ausgabe des Status (1 wenn eine oder mehrere Lampen an sind, o wenn ALLE Lampen aus sind)

Zweck ist die korrekte Statusanzeige für "Alles Aus" Schalter. 
.....
*/


// -- zum ablegen eines kommandos, die in KNXCommandSequence gespeichert werden
class KNXMultiSwitchStatusObject {
	public:	
		KNXMultiSwitchStatusObject(KNXObject* obj);
		KNXMultiSwitchStatusObject* next;
		KNXObject *object;
};


class KNXMultiSwitchStatus : public KNXObject{
	public:
		KNXMultiSwitchStatus(uint16_t statusGA = 0);
		void add(KNXObject* obj); // eine überwachte Lampe hinzufügen
		void add(KNXObject& obj); // eine überwachte Lampe hinzufügen
		void doIt();
		void print();
		void set(uint8_t); // set of multi switch switches ALL switches to on/off !
	private:
		KNXMultiSwitchStatusObject *switchList;
	
}; // end class KNXMultiSwitchStatus


#endif //KNXMultiSwitchStatus_h