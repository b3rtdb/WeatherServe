// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!


#ifndef KNXConnection_simknx_h
#define KNXConnection_simknx_h

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif


// comment or define the port where debug messages should be print.
#define KNXSerialStream     Serial1
#define KNXConnectionDebug  Serial
#define MaxListeningObjects 256
#define KNXStreamBUFFER     64

#include <KNXObject.h>



class KNXConnection
{
  public:
		KNXConnection();

	// sends the received value (SIM KNX Data String) to all objects
		virtual void sendDataToObject(uint16_t ga, char* data) const;

	// method called within the loop -> all loop functions come here !
	// call parent doIt if overwriting. Here the doIt of all KNXObjects are called.
		virtual void doIt();

	// send a read request to the Bus (result automatically read via the object)
		virtual void readRequest(uint16_t ga) const;

	// listening Objects / Object management / Iterator
		virtual void addListeningObject(KNXObject*);

		virtual KNXObject* nextObject() { return listeningObjects[index++]; }
		virtual bool isLast() const { return ((listeningObjects[index+1] != 0) && (listeningObjects[index+1]!=NULL)); }
		virtual void restartIterator() { index=0; }
		KNXObject* getObjectFromGA_unused(uint16_t ga);

		void readSerial();   // has to be public for interrupt call

	// write KNX Telegram to Bus, not used with KNX Objects, just for direct writing
	// only Bit or Byte Objects.
		void write(uint16_t ga, uint8_t data, uint8_t bits);

	protected:
		KNXObject *listeningObjects[MaxListeningObjects];
		uint8_t index; // current index of array (for iterator)

	private:
	// --- serial I/O management
		// HardwareSerial *KNXSerialStream;
		char incomingByte;         
		char buffer[KNXStreamBUFFER];   
		int  bufPos;                      
		char term;                       
		char *last;      

		void incoming();
		void clearBuffer(); 
		char *getBuffer() { return buffer ;} 
		

};



#endif 