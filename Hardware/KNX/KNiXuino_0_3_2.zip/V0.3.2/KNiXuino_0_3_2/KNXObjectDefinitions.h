// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!

#ifndef KNXObjectDefinitions_h
#define KNXObjectDefinitions_h
       
#include "KNXConnection.h"
#include "KNXObject.h"
/*
#include "KNXBasicObjectTypes.h"
#include "KNXPresenceSimulation.h";
#include "KNXMultiSwitchStatus.h";
#include "KNXCommandSequence.h";
#include "KNXStatusTimer.h";
*/
KNXConnection knx;


// --- Beleuchtung ---
KNXObject  eg_buero               (2561, (uint16_t)2562);
KNXObject  eg_wz_couch            (ga(1,2,5),  ga(1,2,6));
KNXObject  eg_wz_wand             (ga(1,2,10), ga(1,2,11));
KNXObject  eg_wz_tv               (ga(1,2,15), ga(1,2,16));
KNXObject  eg_kue_insel           (ga(1,2,20), ga(1,2,21));
KNXObject  eg_kue_insel_dim       (ga(1,2,23), 0, 1);
KNXObject  eg_kue_spots           (ga(1,2,25), ga(1,2,26));
KNXObject  eg_kue_spots_dim       (ga(1,2,28), 0, 1);
KNXObject  eg_kue_wand            (ga(1,2,30), ga(1,2,31));
KNXObject  eg_ez_tisch            (ga(1,2,35), ga(1,2,36));
KNXObject  eg_ez_spots            (ga(1,2,40), ga(1,2,41));
KNXObject  eg_ez_spots_dim        (ga(1,2,43));
KNXObject  eg_terrasse            (ga(1,2,45), ga(1,2,46));
KNXObject  eg_wc                  (ga(1,2,50), ga(1,2,51));
KNXObject  eg_wc_dim              (ga(1,2,52), 0, 1);
KNXObject  eg_bad                 (ga(1,2,55), ga(1,2,56));
KNXObject  eg_sz_decke            (ga(1,2,60), ga(1,2,61));
KNXObject  eg_sz_links            (ga(1,2,65), ga(1,2,66));
KNXObject  eg_sz_rechts           (ga(1,2,71), ga(1,2,72));
KNXObject  eg_sz_schrank          (ga(1,2,75), ga(1,2,76));
KNXObject  eg_diele               (ga(1,2,80), ga(1,2,81));
KNXObject  eg_diele_dim           (ga(1,2,84), ga(1,2,84), 1);
KNXObject  eg_diele_reldim        (ga(1,2,83), (byte) 1);
KNXObject  eg_aquarium            (ga(1,2,85), ga(1,2,86));
KNXObject  eg_strom_tv            (ga(4,1,10), ga(4,1,11));


KNXObject  dg_kz_ost_wandlampen    (ga(1,1,1), ga(1,1,2));
KNXObject  dg_kz_ost_deckenlicht   (ga(1,1,5), ga(1,1,6));
KNXObject  dg_kz_sued              (ga(1,1,10), ga(1,1,11));
KNXObject  dg_kz_west_deckenlicht  (ga(1,1,15), ga(1,1,16));
KNXObject  dg_kz_west_gallerie     (ga(1,1,20), ga(1,1,21));
KNXObject  dg_bad                  (ga(1,1,25), ga(1,1,26));
KNXObject  dg_gang                 (ga(1,1,35), ga(1,1,36));
KNXObject  dg_gang_dim             (ga(1,1,37));

KNXObject  eingang_vorraum         (ga(1,3,1), ga(1,3,2));

KNXObject  ke_werkstatt            (ga(3,1,5), ga(3,1,6));
KNXObject  ke_waschkueche          (ga(3,1,10), ga(3,1,11));
KNXObject  ke_hobbyraum            (ga(3,1,15), ga(3,1,16));
KNXObject  ke_gang                 (ga(3,1,20), ga(3,1,21));
KNXObject  ke_heizraum             (ga(3,1,45), ga(3,1,46));


KNXObject  praxis_wand             (ga(3,1,30), ga(3,1,31));
KNXObject  praxis_wartezimmer      (ga(3,1,35), ga(3,1,36));
KNXObject  praxis_decke            (ga(3,1,40), ga(3,1,41));

KNXObject  garten_pool             (ga(3,1,50), ga(3,1,51));
KNXObject  garten_strom            (ga(3,1,55), ga(3,1,56));

// beleuchtung - Zentralfunktionen
KNXObject  alles_aus               (ga(1,7,1));
KNXObject  kue_ez_aus              (ga(1,7,3));
KNXObject  sz_aus                  (ga(1,7,4));

KNXObject  kz_aus                  (ga(1,7,10));
KNXObject  kz_west_aus             (ga(1,7,13));
KNXObject  kz_ost_aus              (ga(1,7,16));

KNXObject  wz_aus                  (ga(1,7,20));

KNXObject  werkstatt_aus           (ga(3,1,100));
KNXObject  ke_aus                  (ga(3,1,101));

//KNXMultiSwitchStatus st_wz      (ga(4,0,10));        // wohnzimmer 
/*
KNXMultiSwitchStatus st_kue_ez;    // esszimmer & Küche
KNXMultiSwitchStatus st_sz_eltern; // SZ EG & Bad Eltern
KNXMultiSwitchStatus st_kz_ost;    // Kinderzimmer       
KNXMultiSwitchStatus st_kz_west;   // Kinderzimmer       
KNXMultiSwitchStatus st_kz;        // Kinderzimmer       
KNXMultiSwitchStatus st_dg;        // ganzes DG mit Bad und Gang
KNXMultiSwitchStatus st_eg;        // ganzes EG mit Bad, WC, Gang, Büro usw.
KNXMultiSwitchStatus st_ke;        // Keller mit Hobbyraum, Werkstatt, Waschkueche, Gang
KNXMultiSwitchStatus st_praxis; 
KNXMultiSwitchStatus st_alles;     // für alles aus schalter am Eingang -> alles ohne Praxis und Eingang
*/



// ------------------ Beschattung -----------------------------
KNXObject  eg__west_aa            (0x1214); // 2-2-20
KNXObject  eg__west_stop          (0x1215); // 2-2-21  Stop und Lamellenverstellung
KNXObject  eg__west_pos           (ga(2,2,23),0,1);
KNXObject  eg__west_lamellenpos   (ga(2,2,24),0,1);
KNXObject  eg__west_lamellenpos_status (ga(2,2,40),0,1);

KNXObject  eg__sz_aa               (ga(2,2,25));
KNXObject  eg__sz_stop             (ga(2,2,26));
KNXObject  eg__sz_position         (ga(2,2,28),0,1);
KNXObject  eg__sz_pos_status       (ga(2,2,27),0,1);

KNXObject  eg__wz_fenster_aa       (ga(2,2,1));
KNXObject  eg__wz_fenster_stop     (ga(2,2,2));

KNXObject  eg__wz_tuer_aa          (ga(2,2,5));
KNXObject  eg__wz_tuer_stop        (ga(2,2,6));

KNXObject  eg__kue_aa              (ga(2,2,10));
KNXObject  eg__kue_stop            (ga(2,2,11));

KNXObject  eg__ez_tuer_aa          (ga(2,2,15));
KNXObject  eg__ez_tuer_stop        (ga(2,2,16));


KNXObject  dg__kz_ost_aa           (ga(2,1,1));
KNXObject  dg__kz_ost_stop         (ga(2,1,2));

KNXObject  dg__kz_sued_aa          (ga(2,1,5));
KNXObject  dg__kz_sued_stop        (ga(2,1,6));

KNXObject  dg__kz_west_aa          (ga(2,1,10));
KNXObject  dg__kz_west_stop        (ga(2,1,11));


// Beschattung - Zentralfunktionen

KNXObject  dg__aa                  (ga(2,3,1));
KNXObject  dg__stop                (ga(2,3,2));
KNXObject  eg__aa                  (ga(2,3,10));
KNXObject  eg__stop                (ga(2,3,11));
KNXObject  schlafen__aa            (ga(2,3,20));
KNXObject  schlafen__stop          (ga(2,3,21));


// ------------------- KNiXUino Funtionen ----------------------

// KNXPresenceSimulation presenceSim;

//KNXCommandSequence nachtmodusEin;
//KNXCommandSequence nachtmodusAus;

// KNXStatusTimer c_alles_aus (c_isOff, st_alles); // seit wann ist alles im Haus aus, außer Praxis und Eingang - für Alarm



void objectSettings() {


  eg_buero.setReadRqBit(1);
  eg_wz_couch.setReadRqBit(1);
  eg_wz_wand.setReadRqBit(1);
  eg_wz_tv .setReadRqBit(1);
  ke_werkstatt .setReadRqBit(1);
  ke_hobbyraum .setReadRqBit(1);
  ke_gang .setReadRqBit(1);
  dg_bad .setReadRqBit(1);
  dg_gang .setReadRqBit(1);


// -------------------------- Multistatus ----------------------	

/*
  st_wz.add (eg_wz_couch);
  st_wz.add (eg_wz_wand);
  st_wz.add (eg_wz_tv);
/*
  st_kue_ez.add(eg_kue_insel);
  st_kue_ez.add(eg_kue_spots);
  st_kue_ez.add(eg_kue_wand);
  st_kue_ez.add(eg_ez_tisch);
  st_kue_ez.add(eg_ez_spots);
  st_kue_ez.add(eg_aquarium);
/*
  st_sz_eltern.add(eg_sz_decke);
  st_sz_eltern.add(eg_sz_links);
  st_sz_eltern.add(eg_sz_rechts);
  st_sz_eltern.add(eg_sz_schrank);
  st_sz_eltern.add(eg_bad);

  st_eg.add(st_kue_ez);
  st_eg.add(eg_buero);
  st_eg.add(eg_wc);
  st_eg.add(eg_bad);
  st_eg.add(st_sz_eltern);
	
  st_kz_ost.add(dg_kz_ost_wandlampen);
  st_kz_ost.add(dg_kz_ost_deckenlicht);

  st_kz_west.add(dg_kz_west_deckenlicht);
  st_kz_west.add(dg_kz_west_gallerie);
  st_kz.add(dg_kz_sued);
  st_kz.add(st_kz_west);
  st_kz.add(st_kz_ost);

  st_dg.add(st_kz);
  st_dg.add(dg_gang);
  st_dg.add(dg_bad);
	

  st_ke.add(ke_werkstatt);
  st_ke.add(ke_waschkueche);
  st_ke.add(ke_hobbyraum);
  st_ke.add(ke_gang);
  st_ke.add(ke_heizraum);

  st_praxis.add(praxis_wand);
  st_praxis.add(praxis_wartezimmer);
  st_praxis.add(praxis_decke);

  st_alles.add(st_eg);
  st_alles.add(st_dg);
  st_alles.add(st_ke);









*/

/*
	presenceSim.add (eg_buero,    15,    60*30,  30,     60*60);
	presenceSim.add (eg_aquarium, 60*15, 60*60,  20,     60*5);
	presenceSim.add (eg_wc,       40,    180,    60*20,  60*60);
	presenceSim.add (eg_diele,    15,    60*30,  30,     60*60);
	presenceSim.add (eg_kue_wand, 15,    60*30,  30,     60*60);
	presenceSim.off();


/*
	eg_buero.setWebBits(true);
	eg_diele.setWebBits(true);
	eg_diele_dim.setWebBits(true);

*/



  //nachtmodusEin.setInternalBit(1);
  //nachtmodusEin.setStatusGA(ga(4,0,2));
  //nachtmodusEin.addCommand(new KNXCommand(st_wz, 0, 0));
  //nachtmodusEin.addCommand(new KNXCommand(st_ezkue, 0, 0));
  //nachtmodusEin.addCommand(new KNXCommand(eg_strom_tv, 0, 0));
  /*nachtmodusEin.addCommand(new KNXCommand(eg_diele_dim, 180, 0));
  nachtmodusEin.addCommand(new KNXCommand(eg_wc_dim, 180, 0));
  nachtmodusEin.addCommand(new KNXCommand(eg_wc, 0, 60));
  nachtmodusEin.addCommand(new KNXCommand(eg_diele, 0, 60));
  nachtmodusEin.addCommand(new KNXCommand(keller_alles_aus, 0, 60));
  nachtmodusEin.on();
*/
  //nachtmodusAus.setInternalBit(1);
  //nachtmodusAus.addCommand(new KNXCommand(eg_diele_dim, 254, 0));
  //nachtmodusAus.addCommand(new KNXCommand(eg_wc_dim, 254, 0));
  //nachtmodusAus.addCommand(new KNXCommand(eg_wc, 0, 60));
  //nachtmodusAus.addCommand(new KNXCommand(eg_diele, 0, 60));
  //nachtmodusAus.on();

  //nachtmodusEin.addCommand(new KNXCommand(zent_alles_aus, 0, 50));

}

#endif //KNXObjectDefinitions_h