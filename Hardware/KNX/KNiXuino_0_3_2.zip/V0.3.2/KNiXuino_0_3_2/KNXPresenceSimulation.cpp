// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!


#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include "KNXPresenceSimulation.h"


KNXPresenceSimulation::KNXPresenceSimulation(uint16_t ga): KNXObject(ga) {
	objectList = NULL;
	// Presence Simulation is a "switch" that is handled inside the Arduino
	// so it is internal. That makes it switchable via the KNX when a groupAddress
	// is set. If you only turn it on and off internally, you can use 0 as group address
	setInternalBit(1);
	randomSeed(millis());
}


void KNXPresenceSimulation::doIt() {
	if (get() == 0) return; // Presence SImulation is switched off -> go back
	KNXPresenceSimulationObj *ptr = objectList;
	while(ptr != NULL) {
		ptr->doIt();
		ptr = ptr->next;		
	}
} // end method doIt

void KNXPresenceSimulation::addObject(KNXPresenceSimulationObj* obj) {
	obj->next = objectList;
	objectList = obj;	
}

void KNXPresenceSimulation::add(KNXObject &obj, int minOn, int maxOn, int minOff, int maxOff) {
	KNXPresenceSimulationObj* newObj = new KNXPresenceSimulationObj(&obj, minOn, maxOn, minOff, maxOff);
	addObject(newObj);
}

void KNXPresenceSimulation::set(uint8_t d) {
			#if defined(KNXConnectionDebug)
				KNXConnectionDebug.print("Presence Simulator switched to:");
				KNXConnectionDebug.println(d);
			#endif
	randomSeed(millis());
	KNXObject::set(d);
	setAllObjects(d);
}


void KNXPresenceSimulation::setAllObjects(uint8_t value) {
	KNXPresenceSimulationObj *ptr = objectList;
	while(ptr != NULL) {
		ptr->set(value);
		ptr = ptr->next;		
	}

}


// ----------------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------------


void KNXPresenceSimulationObj::set(uint8_t v) {
	object->set(v);
	actualValue = v;
	planNextChange();
	}


// times in seconds !
KNXPresenceSimulationObj::KNXPresenceSimulationObj(KNXObject* obj, uint16_t minOn, uint16_t maxOn, uint16_t minOff, uint16_t maxOff)
{
	object = obj;
	minOnTime = minOn;
	minOffTime = minOff;
	maxOnTime = maxOn;
	maxOffTime = maxOff;
	actualValue = 0;
	next = NULL;
	elapsed = millis();	
	planNextChange();
}


void KNXPresenceSimulationObj::doIt() {
	if (((millis()-elapsed)/1000) > delay) {
		toggle();
		planNextChange();	
	}
}



void KNXPresenceSimulationObj::toggle() {
	actualValue = !actualValue;
	object->set(actualValue);
}



void KNXPresenceSimulationObj::planNextChange() {
	elapsed = millis();
	
	if (actualValue) {
		delay = random(minOnTime, maxOnTime);
	}	
	else
	{
		delay = random(minOffTime, maxOffTime);
	}	
			#if defined(KNXConnectionDebug)
				KNXConnectionDebug.print("Presence Simulator: next toggle in sec:");
				KNXConnectionDebug.println(delay);
			#endif
}

