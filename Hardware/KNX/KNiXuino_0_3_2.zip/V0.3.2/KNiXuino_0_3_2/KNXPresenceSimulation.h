// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!


#ifndef KNXPresenceSimulation_h
#define KNXPresenceSimulation_h

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
#include "KNXConnection.h" 

class KNXPresenceSimulationObj
{
	public:
		KNXPresenceSimulationObj(KNXObject*, uint16_t minOn, uint16_t maxOn, uint16_t minOff, uint16_t maxOff); // times in seconds
		KNXPresenceSimulationObj* next;

		void doIt();
		void toggle();	
		void set(uint8_t v);	
	private:
		uint16_t minOnTime;
		uint16_t minOffTime;
		uint16_t maxOnTime;
		uint16_t maxOffTime;
		uint8_t  actualValue;
		uint32_t delay;
		uint32_t elapsed;
		
		void planNextChange();
		KNXObject *object;
};



class KNXPresenceSimulation:public KNXObject {
	public:
		KNXPresenceSimulation(uint16_t ga=0);	
		void add(KNXObject &obj, int minOn, int maxOn, int minOff, int maxOff);
		void addObject(KNXPresenceSimulationObj* obj);
		void doIt();
	private:
		KNXPresenceSimulationObj *objectList;
		void set(uint8_t);
		void setAllObjects(uint8_t);
		
}; // end class KNXPresenceSimulation



#endif //KNXPresenceSimulation_h