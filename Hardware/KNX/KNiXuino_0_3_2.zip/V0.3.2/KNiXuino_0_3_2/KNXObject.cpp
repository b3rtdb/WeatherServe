// ************** KNiXuino - KNX Bus and Arduino ****************
// for further info check http://www.knixuino.com
// Version info - _readme.txt
// Copyright info - _licence.txt
// Do not remove this headerinfo !!!!


#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include "KNXObject.h"
#include "KNXConnection.h"

extern KNXConnection knx;

/*
	uint8_t getFirst(uint16_t ad) {return ad >> 11;}
    uint8_t getSecond(uint16_t ad) {
        	uint8_t hb = highByte(ad);
        	return hb & B00000111;
        	}
    uint8_t getThird(uint16_t ad) {return lowByte(ad);}
*/



void KNXObject::receivedFromKNX(uint16_t ga, char* value) {
	if (ga == groupAddress || ga == statusGA) {
		char* tt;
		char* lim = (char*)" $";

		uint8_t sz;
		if (size==0) sz = 1; else sz = size;

	    for (uint8_t i = 0; i < sz; i++) {
    		tt = strtok_r(NULL, lim, &value);
	    	data[i]=hex2Byte(tt);
	    }

	// received the value via the Status GA -> set Stauts to verified
	if (isCheckingStatus() && ga == statusGA) {
		setStatusBit(1);
	}

	// if Object is internal write out status message
	if (ga == groupAddress) {
		if (isCheckingStatus()) { 
			if (getInternalBit()) { 
					writeToKNX(statusGA);
					setStatusBit(1);
				}
			else { 
					setStatusBit(0);
			}
		}
	}
	
	}	
}	


KNXObject::KNXObject(uint16_t ga, uint8_t s):KNXObject(ga, 0, s) { }

KNXObject::KNXObject(uint16_t ga, uint16_t sa, uint8_t s):groupAddress(ga), statusGA(sa), size(s) {
	flags = 0; // set all Bits to 0 !
	knx.addListeningObject(this); 
	
	if (size == 0) data = (uint8_t *) calloc(1, sizeof(uint8_t));
	else data = (uint8_t *) calloc(size, sizeof(uint8_t));
}

KNXObject::~KNXObject() { free(data); }



boolean KNXObject::isListeningTo(uint16_t ga) const {
	if (ga == 0 || groupAddress == 0) return false;
	if (ga == groupAddress) return true;
	if (statusGA == 0) return false;
	if (statusGA == ga) return true;
	return false;
}


void KNXObject::readRequest() { 
	knx.readRequest(groupAddress);	
}





void KNXObject::writeToKNX(uint16_t group) {	
	if (group==0) group = (long) groupAddress;
	KNXSerialStream.print("tds ($");
	KNXSerialStream.print(group, 16);	
	if (size == 0) {
		KNXSerialStream.print(") $");
		KNXSerialStream.print(data[0], HEX);		
	}
	else {
		KNXSerialStream.print(" $");
		KNXSerialStream.print(size, HEX);
		KNXSerialStream.print(")");
	
		for (uint8_t i = 0; i < size; i++) {
			KNXSerialStream.print(" $");
			KNXSerialStream.print(data[i], HEX);
		}
	}
	KNXSerialStream.println("");
	
  #if defined(KNXConnectionDebug)
	KNXConnectionDebug.print("tds ($");
	KNXConnectionDebug.print(group, 16);	
	if (size == 0) {
		KNXConnectionDebug.print(") $");
		KNXConnectionDebug.print(data[0], HEX);		
	}
	else {
		KNXConnectionDebug.print(" $");
		KNXConnectionDebug.print(size, HEX);
		KNXConnectionDebug.print(")");
	
		for (uint8_t i = 0; i < size; i++) {
			KNXConnectionDebug.print(" $");
			KNXConnectionDebug.print(data[i], HEX);
		}
	}
	KNXConnectionDebug.println("");
	
  #endif
}


void KNXObject::set(uint8_t d) {
	this->data[0] = d;
	if (getInternalBit()) { // Arduino is the device -> send ACK on StatusGA
		if (isCheckingStatus()) { writeToKNX(statusGA); }	
	}
	else {
		writeToKNX();
	}
}



void KNXObject::setLong(const uint8_t source[]) {
	for (uint8_t i=0; i < size ; i++) {
		data[i] = source[i]; 
	}
	
	if (getInternalBit()) { // Arduino is the device -> send ACK on StatusGA
		if (isCheckingStatus()) { writeToKNX(statusGA); }	
	}
	else {
		writeToKNX();
	}
}

void KNXObject::setLong(const uint16_t d) { 
		uint8_t ar[2];
		ar[1] = d & 0xFF;
		ar[0] = d >> 8;
		setLong (ar);
}



void KNXObject::print() {
	Serial.println("-------------------");
	Serial.print("Size:"); 
	Serial.println(size);
	
	Serial.print("Value:"); 
	
	if (size < 2) {	Serial.println(get()); }
	else {
		for (uint8_t i=0; i < size ; i++) {
			Serial.print(data[i]); Serial.print(" ");
		}
		Serial.println("");
	}
	
	
	/*if (isCheckingStatus()) {
			Serial.print("Status confirmed:"); 
			Serial.println(getStatusBit());
		}
	*/
}


// converts 1 HEX Byte ("$1A") to corresponding byte number Value
uint8_t KNXObject::hex2Byte(char* hex) {
		char part[8];
		strcpy (part,"0x");
		strcat(part, hex);
		return (strtol(part, NULL, 16));
}

