
#include "KNXTime.h"
//#include <TimeLib.h>

// ----------------- KNX Temperature ------------------------------

KNXTime::KNXTime(uint16_t ga): KNXObject(ga, 0, 3) {}

// convert 2-Byte Data to a float variable according to DPT9 Specification (Temperature)
void KNXTime::setT(uint8_t h, uint8_t min, uint8_t sec) {
	setTime((int) h,(int) min,(int) sec, day(), month(), year());
	writeToKNX();
}

void KNXTime::writeToKNX(uint16_t group) {	
	data[0] = (uint8_t)hour();
	data[1] = (uint8_t)minute();
	data[2] = (uint8_t)second();	

	KNXObject::writeToKNX(group);	
}

void KNXTime::receivedFromKNX(uint16_t ga, char* value) {
	KNXObject::receivedFromKNX(ga, value);
	setTime((int) data[0],(int) data[1],(int)data[2], day(), month(), year());
	
}
